"""
=============================================================
 STAGE 2 — Exploratory Data Analysis (EDA)
 Language : Python
 Run      : python eda.py
 Purpose  : Clean data + generate 5 charts for your report
 Input    : ../stage1_data/merged.csv
 Output   : plots/ folder with PNG charts, clean_data.csv
=============================================================
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import os

# ─── CONFIG ───────────────────────────────────────────────────
INPUT_FILE  = "../stage1_data/merged.csv"
OUTPUT_CSV  = "clean_data.csv"
PLOTS_DIR   = "plots"

os.makedirs(PLOTS_DIR, exist_ok=True)
sns.set_theme(style="whitegrid", palette="muted")

# ─── STEP 1: Load & inspect ───────────────────────────────────
print("[1/6] Loading data...")
df = pd.read_csv(INPUT_FILE, encoding="latin1", low_memory=False)
print(f"      Raw shape: {df.shape}")
print(f"      Columns  : {list(df.columns)}")

# ─── STEP 2: Keep useful columns ──────────────────────────────
print("[2/6] Selecting columns...")

WANTED = ["Date","HomeTeam","AwayTeam",
          "FTHG","FTAG","FTR",          # goals & result
          "HS","AS",                     # shots
          "HST","AST",                   # shots on target
          "HC","AC",                     # corners
          "HY","AY",                     # yellow cards
          "HR","AR",                     # red cards
          "season_file"]

existing = [c for c in WANTED if c in df.columns]
df = df[existing].copy()

# ─── STEP 3: Clean ────────────────────────────────────────────
print("[3/6] Cleaning...")
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, errors="coerce")
df = df.dropna(subset=["FTR","HomeTeam","AwayTeam","FTHG","FTAG","Date"])
df = df[df["FTR"].isin(["H","D","A"])]       # keep valid results only
df = df.fillna(0)
df = df.sort_values("Date").reset_index(drop=True)
df["Year"] = df["Date"].dt.year
print(f"      Clean shape: {df.shape}")

df.to_csv(OUTPUT_CSV, index=False)
print(f"      Saved → {OUTPUT_CSV}")

# ─── STEP 4: Charts ───────────────────────────────────────────
print("[4/6] Generating charts...")

# ── Chart 1: Result distribution (pie chart) ──────────────────
counts = df["FTR"].value_counts()
labels = ["Home Win","Draw","Away Win"]
vals   = [counts.get("H",0), counts.get("D",0), counts.get("A",0)]
colors = ["#38bdf8","#facc15","#818cf8"]

fig, ax = plt.subplots(figsize=(7,5))
wedges, texts, autotexts = ax.pie(
    vals, labels=labels, colors=colors, autopct="%1.1f%%",
    startangle=140, pctdistance=0.82,
    wedgeprops=dict(linewidth=1.5, edgecolor="white"))
ax.set_title("Premier League Result Distribution\n(all seasons)", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/01_result_distribution.png", dpi=150)
plt.close()
print("      Saved: 01_result_distribution.png")

# ── Chart 2: Goals per season (line chart) ────────────────────
yearly = df.groupby("Year")[["FTHG","FTAG"]].mean().reset_index()
yearly = yearly[(yearly["Year"] >= 2010) & (yearly["Year"] <= 2024)]

fig, ax = plt.subplots(figsize=(10,5))
ax.plot(yearly["Year"], yearly["FTHG"], marker="o", linewidth=2,
        color="#38bdf8", label="Avg Home Goals")
ax.plot(yearly["Year"], yearly["FTAG"], marker="s", linewidth=2,
        color="#818cf8", label="Avg Away Goals")
ax.fill_between(yearly["Year"], yearly["FTHG"], yearly["FTAG"], alpha=0.08, color="#38bdf8")
ax.set_title("Average Goals Per Match by Year", fontsize=14, fontweight="bold")
ax.set_xlabel("Year"); ax.set_ylabel("Average Goals")
ax.legend(); ax.set_xticks(yearly["Year"])
plt.xticks(rotation=45); plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/02_goals_over_time.png", dpi=150)
plt.close()
print("      Saved: 02_goals_over_time.png")

# ── Chart 3: Top 10 teams by wins ─────────────────────────────
home_w = df[df["FTR"]=="H"].groupby("HomeTeam").size()
away_w = df[df["FTR"]=="A"].groupby("AwayTeam").size()
total  = (home_w.add(away_w, fill_value=0)).sort_values(ascending=False).head(10)

fig, ax = plt.subplots(figsize=(10,5))
bars = ax.bar(total.index, total.values, color="#38bdf8", edgecolor="white", linewidth=0.8)
ax.bar_label(bars, padding=3, fontsize=10)
ax.set_title("Top 10 Teams by Total Wins", fontsize=14, fontweight="bold")
ax.set_ylabel("Total Wins"); plt.xticks(rotation=30, ha="right")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/03_top_teams.png", dpi=150)
plt.close()
print("      Saved: 03_top_teams.png")

# ── Chart 4: Home vs Away win rate trend ──────────────────────
yr_res = df.groupby("Year")["FTR"].value_counts(normalize=True).unstack(fill_value=0) * 100
yr_res = yr_res[(yr_res.index >= 2010) & (yr_res.index <= 2024)]

fig, ax = plt.subplots(figsize=(10,5))
if "H" in yr_res: ax.plot(yr_res.index, yr_res["H"], marker="o", color="#38bdf8", label="Home Win %", linewidth=2)
if "D" in yr_res: ax.plot(yr_res.index, yr_res["D"], marker="s", color="#facc15", label="Draw %", linewidth=2)
if "A" in yr_res: ax.plot(yr_res.index, yr_res["A"], marker="^", color="#818cf8", label="Away Win %", linewidth=2)
ax.set_title("Home / Draw / Away Win Rate per Year", fontsize=14, fontweight="bold")
ax.set_ylabel("Percentage (%)"); ax.legend()
ax.set_xticks(yr_res.index); plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/04_win_rate_trend.png", dpi=150)
plt.close()
print("      Saved: 04_win_rate_trend.png")

# ── Chart 5: Goals scored distribution (histogram) ────────────
fig, axes = plt.subplots(1, 2, figsize=(12,5), sharey=True)
axes[0].hist(df["FTHG"], bins=range(0,11), color="#38bdf8", edgecolor="white", rwidth=0.85)
axes[0].set_title("Home Goals Distribution"); axes[0].set_xlabel("Goals")
axes[1].hist(df["FTAG"], bins=range(0,11), color="#818cf8", edgecolor="white", rwidth=0.85)
axes[1].set_title("Away Goals Distribution"); axes[1].set_xlabel("Goals")
fig.suptitle("Goal Frequency Distribution", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/05_goals_distribution.png", dpi=150)
plt.close()
print("      Saved: 05_goals_distribution.png")

print("\n[5/6] Summary stats:")
print(df[["FTHG","FTAG"]].describe().round(2).to_string())

print("\n✓  Stage 2 complete. Charts saved in plots/ folder.")
print("   Run stage3_features/engineer_features.py next.")
