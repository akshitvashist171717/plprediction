# Premier League Match Predictor
## ML Course Project — Complete Guide

---

## Project Structure

```
pl_project/
│
├── stage1_data/
│   └── load_data.py          ← PYTHON: downloads + merges all CSVs
│
├── stage2_eda/
│   └── eda.py                ← PYTHON: cleans data + creates 5 charts
│
├── stage3_features/
│   └── engineer_features.py  ← PYTHON: creates ML features (rolling form, H2H)
│
├── stage4_models/
│   └── train_models.py       ← PYTHON: trains 3 models, saves to disk
│
├── stage5_evaluation/
│   └── api.py                ← PYTHON (Flask): REST API serving predictions
│
└── stage6_frontend/
    ├── index.html            ← HTML: page structure
    ├── css/style.css         ← CSS: all styling
    └── js/app.js             ← JavaScript: UI logic + API calls
```

---

## Languages Used

| Stage | File | Language | Purpose |
|-------|------|----------|---------|
| 1 | load_data.py | Python | Data collection |
| 2 | eda.py | Python | Exploratory analysis |
| 3 | engineer_features.py | Python | Feature creation |
| 4 | train_models.py | Python | ML model training |
| 5 | api.py | Python (Flask) | REST API backend |
| 6 | index.html | HTML | Page structure |
| 6 | style.css | CSS | Styling / design |
| 6 | app.js | JavaScript | Frontend logic |

---

## How to Run — Step by Step

### Step 0: Install everything (once only)
```bash
pip install pandas numpy scikit-learn xgboost matplotlib seaborn flask flask-cors
```

### Step 1: Download + merge data
```bash
cd stage1_data
python load_data.py
```
Output: `stage1_data/merged.csv`

> If auto-download fails, manually download CSV files from:
> https://www.football-data.co.uk/englandm.php
> Save them all into stage1_data/raw/

### Step 2: Clean + explore data
```bash
cd ../stage2_eda
python eda.py
```
Output: `stage2_eda/clean_data.csv` + `stage2_eda/plots/` (5 PNG charts)

### Step 3: Create ML features
```bash
cd ../stage3_features
python engineer_features.py
```
Output: `stage3_features/features.csv`
⏱ Takes 3–5 minutes

### Step 4: Train the 3 models
```bash
cd ../stage4_models
python train_models.py
```
Output: `stage4_models/models/` (pkl files) + evaluation plots

### Step 5: Start the prediction API
```bash
cd ../stage5_evaluation
python api.py
```
API runs at: http://localhost:5000

Test it works:
```bash
curl http://localhost:5000/health
```

### Step 6: Open the website
Open `stage6_frontend/index.html` in your browser.
If the API (Step 5) is running, predictions come from your real trained model.
If not, the site runs in demo mode with simulated probabilities.

---

## API Endpoints

| Method | Endpoint | What it does |
|--------|----------|--------------|
| GET | /health | Check if server is running |
| GET | /teams | Get list of all teams |
| GET | /accuracies | Get model accuracy scores |
| POST | /predict | Get match prediction |

### Example prediction request
```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "model": "xgb",
    "home_team": "Arsenal",
    "away_team": "Chelsea",
    "home_form_gf": 8,
    "home_form_ga": 3,
    "home_form_wins": 3,
    "home_form_pts": 9,
    "home_goal_diff": 5,
    "away_form_gf": 6,
    "away_form_ga": 5,
    "away_form_wins": 2,
    "away_form_pts": 6,
    "away_goal_diff": 1,
    "h2h_home_wins": 5,
    "h2h_draws": 3,
    "h2h_away_wins": 2
  }'
```

---

## Expected Accuracies
- Logistic Regression: ~51%
- Random Forest: ~55%
- XGBoost: ~58%

Note: Football is hard to predict. 58% is a good score for this problem.
Professional betting models typically achieve 55–65%.

---

## Files for Report
After running all stages, your report should include:
- `stage2_eda/plots/01_result_distribution.png`
- `stage2_eda/plots/02_goals_over_time.png`
- `stage2_eda/plots/03_top_teams.png`
- `stage2_eda/plots/04_win_rate_trend.png`
- `stage4_models/plots/confusion_matrix_xgb.png`
- `stage4_models/plots/feature_importance.png`
- `stage4_models/plots/model_comparison.png`
