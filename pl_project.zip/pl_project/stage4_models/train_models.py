"""
=============================================================
 STAGE 4 — Model Training
 Language : Python
 Run      : python train_models.py
 Purpose  : Train 3 ML models and save them to disk
 Input    : ../stage3_features/features.csv
 Output   : models/ folder with .pkl files + accuracies.json
=============================================================

MODELS TRAINED:
  1. Logistic Regression  — simple baseline, fast, interpretable
  2. Random Forest        — ensemble of decision trees
  3. XGBoost              — gradient boosting, usually best
"""

import pandas as pd
import numpy as np
import pickle
import json
import os

from sklearn.model_selection  import train_test_split, cross_val_score
from sklearn.preprocessing    import LabelEncoder, StandardScaler
from sklearn.linear_model     import LogisticRegression
from sklearn.ensemble         import RandomForestClassifier
from sklearn.metrics          import (accuracy_score, classification_report,
                                      confusion_matrix)
from xgboost                  import XGBClassifier
import matplotlib.pyplot      as plt
import seaborn                as sns

# ─── CONFIG ───────────────────────────────────────────────────
INPUT_FILE  = "../stage3_features/features.csv"
MODELS_DIR  = "models"
PLOTS_DIR   = "plots"
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(PLOTS_DIR,  exist_ok=True)

# These are the columns the models learn from
FEATURE_COLS = [
    "home_form_gf",   "home_form_ga",
    "home_form_wins", "home_form_pts",
    "home_goal_diff",
    "away_form_gf",   "away_form_ga",
    "away_form_wins", "away_form_pts",
    "away_goal_diff",
    "h2h_home_wins",  "h2h_draws",     "h2h_away_wins",
]

# ─── STEP 1: Load features ────────────────────────────────────
print("[1/7] Loading features...")
df = pd.read_csv(INPUT_FILE)
print(f"      Rows: {len(df)}  |  Columns: {len(df.columns)}")

# ─── STEP 2: Prepare X (inputs) and y (target) ───────────────
print("[2/7] Preparing X and y...")
X = df[FEATURE_COLS]
y = df["FTR"]          # H = Home Win, D = Draw, A = Away Win

# Convert H/D/A labels → 0/1/2 (models need numbers not letters)
le = LabelEncoder()
y_enc = le.fit_transform(y)
print(f"      Class mapping: {dict(zip(le.classes_, le.transform(le.classes_)))}")
print(f"      Class counts : {pd.Series(y).value_counts().to_dict()}")

# ─── STEP 3: Train/test split ─────────────────────────────────
print("[3/7] Splitting data 80% train / 20% test...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y_enc, test_size=0.2, random_state=42, stratify=y_enc)
print(f"      Train: {len(X_train)}  |  Test: {len(X_test)}")

# Scale features for Logistic Regression only
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)

# ─── STEP 4: Train models ─────────────────────────────────────
print("[4/7] Training models...")
results = {}

# ── Model 1: Logistic Regression ──────────────────────────────
print("\n   [Model 1] Logistic Regression...")
lr = LogisticRegression(max_iter=2000, random_state=42, C=1.0)
lr.fit(X_train_scaled, y_train)
lr_preds = lr.predict(X_test_scaled)
lr_acc   = accuracy_score(y_test, lr_preds)
lr_cv    = cross_val_score(lr, scaler.transform(X), y_enc, cv=5).mean()
print(f"           Accuracy : {lr_acc*100:.2f}%")
print(f"           CV Score : {lr_cv*100:.2f}%")
results["Logistic Regression"] = {"accuracy": round(lr_acc*100,2),
                                   "cv_accuracy": round(lr_cv*100,2)}

# ── Model 2: Random Forest ────────────────────────────────────
print("\n   [Model 2] Random Forest...")
rf = RandomForestClassifier(n_estimators=200, max_depth=10,
                             min_samples_leaf=5, random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
rf_preds = rf.predict(X_test)
rf_acc   = accuracy_score(y_test, rf_preds)
rf_cv    = cross_val_score(rf, X, y_enc, cv=5).mean()
print(f"           Accuracy : {rf_acc*100:.2f}%")
print(f"           CV Score : {rf_cv*100:.2f}%")
results["Random Forest"] = {"accuracy": round(rf_acc*100,2),
                             "cv_accuracy": round(rf_cv*100,2)}

# ── Model 3: XGBoost ──────────────────────────────────────────
print("\n   [Model 3] XGBoost...")
xgb = XGBClassifier(n_estimators=300, max_depth=5, learning_rate=0.05,
                     subsample=0.8, colsample_bytree=0.8,
                     eval_metric="mlogloss", random_state=42, n_jobs=-1)
xgb.fit(X_train, y_train,
        eval_set=[(X_test, y_test)], verbose=False)
xgb_preds = xgb.predict(X_test)
xgb_acc   = accuracy_score(y_test, xgb_preds)
xgb_cv    = cross_val_score(xgb, X, y_enc, cv=5).mean()
print(f"           Accuracy : {xgb_acc*100:.2f}%")
print(f"           CV Score : {xgb_cv*100:.2f}%")
results["XGBoost"] = {"accuracy": round(xgb_acc*100,2),
                       "cv_accuracy": round(xgb_cv*100,2)}

# ─── STEP 5: Classification reports ──────────────────────────
print("\n[5/7] Classification Reports...")
for name, preds in [("Logistic Regression", lr_preds),
                    ("Random Forest",        rf_preds),
                    ("XGBoost",              xgb_preds)]:
    print(f"\n--- {name} ---")
    print(classification_report(y_test, preds, target_names=le.classes_))

# ─── STEP 6: Save models to disk ─────────────────────────────
print("[6/7] Saving models...")

# Save all models and helpers as pickle files
# These will be loaded by the Flask API in Stage 5
with open(f"{MODELS_DIR}/logistic_regression.pkl", "wb") as f:
    pickle.dump(lr,  f)
with open(f"{MODELS_DIR}/random_forest.pkl", "wb") as f:
    pickle.dump(rf,  f)
with open(f"{MODELS_DIR}/xgboost.pkl", "wb") as f:
    pickle.dump(xgb, f)
with open(f"{MODELS_DIR}/label_encoder.pkl", "wb") as f:
    pickle.dump(le,  f)
with open(f"{MODELS_DIR}/scaler.pkl", "wb") as f:
    pickle.dump(scaler, f)

# Save results as JSON so frontend can display them
results["feature_cols"] = FEATURE_COLS
with open(f"{MODELS_DIR}/accuracies.json", "w") as f:
    json.dump(results, f, indent=2)

print(f"      Models saved to {MODELS_DIR}/")

# ─── STEP 7: Evaluation plots ────────────────────────────────
print("[7/7] Saving evaluation plots...")

# Confusion matrix for XGBoost (best model)
cm = confusion_matrix(y_test, xgb_preds)
fig, ax = plt.subplots(figsize=(7,5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=le.classes_, yticklabels=le.classes_,
            linewidths=0.5, ax=ax)
ax.set_title("XGBoost — Confusion Matrix", fontsize=14, fontweight="bold")
ax.set_xlabel("Predicted Result"); ax.set_ylabel("Actual Result")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/confusion_matrix_xgb.png", dpi=150)
plt.close()

# Feature importance (XGBoost)
feat_imp = pd.Series(xgb.feature_importances_, index=FEATURE_COLS).sort_values()
fig, ax = plt.subplots(figsize=(9,6))
feat_imp.plot(kind="barh", ax=ax, color="#38bdf8", edgecolor="white")
ax.set_title("XGBoost — Feature Importance", fontsize=14, fontweight="bold")
ax.set_xlabel("Importance Score")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/feature_importance.png", dpi=150)
plt.close()

# Model accuracy comparison
fig, ax = plt.subplots(figsize=(8,5))
names = list(results.keys())[:-1]   # exclude feature_cols key
accs  = [results[n]["accuracy"] for n in names]
colors = ["#64748b","#818cf8","#38bdf8"]
bars = ax.bar(names, accs, color=colors, edgecolor="white", width=0.55)
ax.bar_label(bars, fmt="%.1f%%", padding=3, fontsize=11)
ax.set_ylim(40, 70)
ax.set_title("Model Accuracy Comparison", fontsize=14, fontweight="bold")
ax.set_ylabel("Test Accuracy (%)")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/model_comparison.png", dpi=150)
plt.close()

print(f"      Plots saved to {PLOTS_DIR}/")
print("\n─── Final Results ────────────────────────────────────────")
for model, res in results.items():
    if model == "feature_cols": continue
    print(f"  {model:<25} Accuracy: {res['accuracy']}%   CV: {res['cv_accuracy']}%")
print("\n✓  Stage 4 complete. Run stage5_evaluation/api.py next.")
