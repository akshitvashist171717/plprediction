"""
=============================================================
 STAGE 5 — REST API Backend
 Language : Python (Flask)
 Run      : python api.py
 Purpose  : Serve predictions from trained models via HTTP
 Endpoint : http://localhost:5000/predict
=============================================================

Install Flask first:
    pip install flask flask-cors

Then run:
    python api.py

The frontend (Stage 6) calls this API to get predictions.
"""

from flask       import Flask, request, jsonify
from flask_cors  import CORS
import pickle
import json
import numpy  as np
import pandas as pd
import os

app = Flask(__name__)
CORS(app)   # allows the HTML frontend to call this API

# ─── Load saved models ────────────────────────────────────────
MODELS_DIR = "../stage4_models/models"

print("Loading models from disk...")

with open(f"{MODELS_DIR}/logistic_regression.pkl", "rb") as f:
    lr_model = pickle.load(f)
with open(f"{MODELS_DIR}/random_forest.pkl", "rb") as f:
    rf_model = pickle.load(f)
with open(f"{MODELS_DIR}/xgboost.pkl", "rb") as f:
    xgb_model = pickle.load(f)
with open(f"{MODELS_DIR}/label_encoder.pkl", "rb") as f:
    label_enc = pickle.load(f)
with open(f"{MODELS_DIR}/scaler.pkl", "rb") as f:
    scaler = pickle.load(f)
with open(f"{MODELS_DIR}/accuracies.json", "r") as f:
    model_info = json.load(f)

FEATURE_COLS = model_info["feature_cols"]
print(f"✓ Models loaded. Features expected: {FEATURE_COLS}")

# Model registry
MODEL_MAP = {
    "xgb" : xgb_model,
    "rf"  : rf_model,
    "lr"  : lr_model,
}
MODEL_NAMES = {
    "xgb": "XGBoost",
    "rf" : "Random Forest",
    "lr" : "Logistic Regression",
}

# ─── ROUTE: Health check ──────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "models_loaded": list(MODEL_MAP.keys())})

# ─── ROUTE: Get model accuracies ─────────────────────────────
@app.route("/accuracies", methods=["GET"])
def accuracies():
    """Returns accuracy of all 3 models for the frontend table."""
    return jsonify({
        "Logistic Regression": model_info.get("Logistic Regression", {}),
        "Random Forest":       model_info.get("Random Forest", {}),
        "XGBoost":             model_info.get("XGBoost", {}),
    })

# ─── ROUTE: Predict match result ─────────────────────────────
@app.route("/predict", methods=["POST"])
def predict():
    """
    POST body (JSON):
    {
        "model": "xgb",       // "xgb" | "rf" | "lr"
        "home_team": "Arsenal",
        "away_team": "Chelsea",
        "home_form_gf":    8,  // goals scored in last 5
        "home_form_ga":    4,  // goals conceded in last 5
        "home_form_wins":  3,
        "home_form_pts":   9,
        "home_goal_diff":  4,
        "away_form_gf":    6,
        "away_form_ga":    5,
        "away_form_wins":  2,
        "away_form_pts":   6,
        "away_goal_diff":  1,
        "h2h_home_wins":   5,
        "h2h_draws":       3,
        "h2h_away_wins":   2
    }
    """
    try:
        data = request.get_json()

        # Validate model choice
        model_key = data.get("model", "xgb").lower()
        if model_key not in MODEL_MAP:
            return jsonify({"error": f"Unknown model '{model_key}'. Use xgb, rf, or lr."}), 400

        model = MODEL_MAP[model_key]

        # Build feature vector in correct order
        row = []
        for col in FEATURE_COLS:
            val = data.get(col)
            if val is None:
                return jsonify({"error": f"Missing feature: '{col}'"}), 400
            row.append(float(val))

        X = np.array([row])

        # Scale for logistic regression
        if model_key == "lr":
            X = scaler.transform(X)

        # Get prediction and probabilities
        pred_class = model.predict(X)[0]
        proba      = model.predict_proba(X)[0]

        # Map back to H/D/A
        classes   = label_enc.classes_          # e.g. ['A','D','H']
        pred_label = label_enc.inverse_transform([pred_class])[0]

        prob_dict = {cls: round(float(p)*100, 1) for cls, p in zip(classes, proba)}

        result_text = {
            "H": f"Home Win — {data.get('home_team','Home')}",
            "D": "Draw",
            "A": f"Away Win — {data.get('away_team','Away')}",
        }.get(pred_label, "Unknown")

        return jsonify({
            "prediction"   : pred_label,      # "H", "D", or "A"
            "result_text"  : result_text,
            "probabilities": prob_dict,        # e.g. {"A":28.1,"D":24.3,"H":47.6}
            "model_used"   : MODEL_NAMES[model_key],
            "accuracy"     : model_info.get(MODEL_NAMES[model_key], {}).get("accuracy", "N/A"),
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ─── ROUTE: List all teams from training data ─────────────────
@app.route("/teams", methods=["GET"])
def teams():
    """Returns all Premier League teams seen in training data."""
    try:
        df = pd.read_csv("../stage2_eda/clean_data.csv")
        all_teams = sorted(set(df["HomeTeam"].dropna().unique()) |
                           set(df["AwayTeam"].dropna().unique()))
        return jsonify({"teams": all_teams})
    except Exception as e:
        # Fallback list if CSV not found
        fallback = [
            "Arsenal","Aston Villa","Brentford","Brighton","Burnley",
            "Chelsea","Crystal Palace","Everton","Fulham","Leeds United",
            "Leicester City","Liverpool","Manchester City","Manchester United",
            "Newcastle United","Norwich City","Sheffield United","Southampton",
            "Tottenham","Watford","West Ham","Wolves"
        ]
        return jsonify({"teams": fallback})

# ─── Run server ───────────────────────────────────────────────
if __name__ == "__main__":
    print("\n─────────────────────────────────────────────")
    print("  PL Predictor API")
    print("  Running at: http://localhost:5000")
    print("  Endpoints:")
    print("    GET  /health       — check server is running")
    print("    GET  /teams        — list all teams")
    print("    GET  /accuracies   — get model accuracy scores")
    print("    POST /predict      — get match prediction")
    print("─────────────────────────────────────────────\n")
    app.run(debug=True, port=5000)
