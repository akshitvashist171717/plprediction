/**
 * =============================================================
 *  STAGE 6 — Frontend JavaScript
 *  Language : JavaScript (Vanilla JS, no framework)
 *  File     : app.js
 *  Purpose  : Handles all UI interactions and API calls
 *  API      : http://localhost:5000  (Flask, Stage 5)
 * =============================================================
 */

"use strict";

// ── Config ────────────────────────────────────────────────────
const API_URL = "http://localhost:5000";  // your Flask API address

// ── Default form values when Flask API is offline ─────────────
// These are pre-calculated averages so the demo still works
const DEMO_FORM = {
  home_form_gf:    7,  home_form_ga:   5, home_form_wins: 2,
  home_form_pts:   6,  home_goal_diff: 2,
  away_form_gf:    5,  away_form_ga:   6, away_form_wins: 1,
  away_form_pts:   3,  away_goal_diff:-1,
  h2h_home_wins:   4,  h2h_draws:      3, h2h_away_wins:  3,
};

// ── State ─────────────────────────────────────────────────────
let activeModel  = "xgb";
let apiOnline    = false;
let teams        = [];

// ── DOM elements ──────────────────────────────────────────────
const homeSelect   = document.getElementById("home-team");
const awaySelect   = document.getElementById("away-team");
const predictBtn   = document.getElementById("predict-btn");
const resultPanel  = document.getElementById("result-panel");
const errorMsg     = document.getElementById("error-msg");
const spinner      = document.getElementById("spinner");
const dotEl        = document.getElementById("api-dot");
const statusText   = document.getElementById("api-status-text");

// ── On page load ──────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  await checkApiHealth();
  await loadTeams();
  await loadModelAccuracies();
});

// ── Check if Flask API is running ─────────────────────────────
async function checkApiHealth() {
  try {
    const res = await fetch(`${API_URL}/health`, { signal: AbortSignal.timeout(2000) });
    if (res.ok) {
      apiOnline = true;
      dotEl.classList.add("online");
      statusText.textContent = "API connected";
    }
  } catch {
    apiOnline = false;
    dotEl.classList.add("offline");
    statusText.textContent = "API offline — demo mode";
  }
}

// ── Load teams from API (or use fallback list) ─────────────────
async function loadTeams() {
  const FALLBACK = [
    "Arsenal","Aston Villa","Brentford","Brighton","Burnley",
    "Chelsea","Crystal Palace","Everton","Fulham","Leeds United",
    "Leicester City","Liverpool","Manchester City","Manchester United",
    "Newcastle United","Norwich City","Sheffield United","Southampton",
    "Tottenham Hotspur","Watford","West Ham United","Wolves"
  ];

  try {
    if (apiOnline) {
      const res  = await fetch(`${API_URL}/teams`);
      const data = await res.json();
      teams = data.teams;
    } else {
      teams = FALLBACK;
    }
  } catch {
    teams = FALLBACK;
  }

  // Populate dropdowns
  [homeSelect, awaySelect].forEach((sel, idx) => {
    sel.innerHTML = `<option value="">Select team...</option>`;
    teams.forEach(t => {
      const opt = document.createElement("option");
      opt.value = opt.textContent = t;
      sel.appendChild(opt);
    });
    // Set defaults
    sel.value = idx === 0 ? "Arsenal" : "Chelsea";
  });
}

// ── Load real model accuracies into the comparison table ──────
async function loadModelAccuracies() {
  if (!apiOnline) return;
  try {
    const res  = await fetch(`${API_URL}/accuracies`);
    const data = await res.json();

    // Update table cells
    const rows = {
      "XGBoost":             { acc: "acc-xgb",  cv: "cv-xgb",  bar: "bar-xgb" },
      "Random Forest":       { acc: "acc-rf",   cv: "cv-rf",   bar: "bar-rf"  },
      "Logistic Regression": { acc: "acc-lr",   cv: "cv-lr",   bar: "bar-lr"  },
    };
    for (const [name, ids] of Object.entries(rows)) {
      if (data[name]) {
        const el = document.getElementById(ids.acc);
        if (el) el.textContent = data[name].accuracy + "%";
        const bar = document.getElementById(ids.bar);
        if (bar) bar.style.width = data[name].accuracy + "%";
      }
    }
  } catch (e) {
    console.warn("Could not load accuracies:", e);
  }
}

// ── Model button selection ────────────────────────────────────
function selectModel(btn) {
  document.querySelectorAll(".model-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  activeModel = btn.dataset.model;
}

// ── Main predict function ─────────────────────────────────────
async function predict() {
  const homeTeam = homeSelect.value;
  const awayTeam = awaySelect.value;

  // Validation
  if (!homeTeam || !awayTeam) {
    showError("Please select both a home team and an away team.");
    return;
  }
  if (homeTeam === awayTeam) {
    showError("Home and away teams cannot be the same.");
    return;
  }
  hideError();

  // Show loading state
  predictBtn.disabled = true;
  spinner.classList.add("show");

  try {
    let result;

    if (apiOnline) {
      // ── Real prediction from Flask API ──────────────────────
      const payload = {
        model:     activeModel,
        home_team: homeTeam,
        away_team: awayTeam,
        ...DEMO_FORM,    // in a real app, these come from live data
      };

      const res = await fetch(`${API_URL}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      result = await res.json();

      if (result.error) throw new Error(result.error);

    } else {
      // ── Demo mode: simulate probabilities ───────────────────
      result = simulatePrediction(homeTeam, awayTeam, activeModel);
    }

    displayResult(homeTeam, awayTeam, result);

  } catch (err) {
    showError(`Prediction failed: ${err.message}`);
  } finally {
    predictBtn.disabled = false;
    spinner.classList.remove("show");
  }
}

// ── Display result in the UI ──────────────────────────────────
function displayResult(homeTeam, awayTeam, result) {
  const probs = result.probabilities; // { H: 47.2, D: 24.1, A: 28.7 }

  // Header
  document.getElementById("result-model-tag").textContent  = result.model_used;
  document.getElementById("result-match-title").textContent = `${homeTeam} vs ${awayTeam}`;

  // Probability bars
  setProb("home", homeTeam + " win", probs["H"] || 0, "bar-home");
  setProb("draw", "Draw",            probs["D"] || 0, "bar-draw");
  setProb("away", awayTeam + " win", probs["A"] || 0, "bar-away");

  // Verdict card
  const pred     = result.prediction;  // "H", "D", or "A"
  const maxProb  = Math.max(probs["H"]||0, probs["D"]||0, probs["A"]||0);
  const verdictEl = document.getElementById("verdict-box");
  verdictEl.className = "verdict " + { H:"home", D:"draw", A:"away" }[pred];

  const icons   = { H: "🏠", D: "🤝", A: "✈️" };
  const texts   = { H: `Home Win — ${homeTeam}`, D: "Match ends in a draw", A: `Away Win — ${awayTeam}` };
  document.getElementById("verdict-icon").textContent = icons[pred];
  document.getElementById("verdict-text").textContent = texts[pred];

  // Stat cards
  document.getElementById("stat-accuracy").textContent   = result.accuracy ? result.accuracy + "%" : "~57%";
  document.getElementById("stat-confidence").textContent  = maxProb.toFixed(1) + "%";

  // Show panel with animation
  resultPanel.classList.remove("show");
  void resultPanel.offsetWidth;            // force reflow to restart animation
  resultPanel.style.display = "block";
  requestAnimationFrame(() => resultPanel.classList.add("show"));
  resultPanel.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

// ── Helper: set one probability bar ──────────────────────────
function setProb(id, label, pct, barClass) {
  document.getElementById(`prob-name-${id}`).textContent = label;
  document.getElementById(`prob-pct-${id}`).textContent  = pct.toFixed(1) + "%";

  // Reset bar then animate
  const bar = document.getElementById(`bar-${id}`);
  bar.style.width = "0%";
  setTimeout(() => { bar.style.width = pct + "%"; }, 60);
}

// ── Demo mode: generate pseudo-realistic probabilities ────────
function simulatePrediction(home, away, model) {
  // Use character codes as a stable seed so same match = same result
  const seed = ([...home].reduce((a,c)=>a+c.charCodeAt(0),0)*3 +
                [...away].reduce((a,c)=>a+c.charCodeAt(0),0)*7 +
                { xgb:11, rf:17, lr:23 }[model]) % 100;

  let h = 36 + (seed % 22);
  let d = 22 + (seed % 12);
  let a = 100 - h - d;
  if (a < 8) { a = 12; h = 100 - d - a; }

  const total = h + d + a;
  h = Math.round(h/total*100);
  d = Math.round(d/total*100);
  a = 100 - h - d;

  const pred = h>=d && h>=a ? "H" : d>=h && d>=a ? "D" : "A";
  const modelNames = { xgb:"XGBoost", rf:"Random Forest", lr:"Logistic Regression" };
  const accs       = { xgb:"~58%", rf:"~55%", lr:"~51%" };

  return {
    prediction:   pred,
    probabilities: { H: h, D: d, A: a },
    model_used:   modelNames[model],
    accuracy:     accs[model],
  };
}

// ── Error helpers ─────────────────────────────────────────────
function showError(msg) {
  errorMsg.textContent = "⚠ " + msg;
  errorMsg.classList.add("show");
}
function hideError() {
  errorMsg.classList.remove("show");
}

// ── Expose functions to HTML onclick attributes ────────────────
window.selectModel = selectModel;
window.predict     = predict;
