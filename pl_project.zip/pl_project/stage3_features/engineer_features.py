"""
=============================================================
 STAGE 3 — Feature Engineering
 Language : Python
 Run      : python engineer_features.py
 Purpose  : Create smart ML features from raw match data
 Input    : ../stage2_eda/clean_data.csv
 Output   : features.csv  (ready for model training)
=============================================================

FEATURES CREATED:
  home_form_gf    — goals scored by home team in last 5 games
  home_form_ga    — goals conceded by home team in last 5 games
  home_form_wins  — wins by home team in last 5 games
  home_form_pts   — points earned by home team in last 5 games
  away_form_gf    — goals scored by away team in last 5 games
  away_form_ga    — goals conceded by away team in last 5 games
  away_form_wins  — wins by away team in last 5 games
  away_form_pts   — points earned by away team in last 5 games
  home_goal_diff  — goal difference (home team, last 5)
  away_goal_diff  — goal difference (away team, last 5)
  h2h_home_wins   — historical head-to-head home wins
  h2h_away_wins   — historical head-to-head away wins
  h2h_draws       — historical head-to-head draws
"""

import pandas as pd
import numpy as np

# ─── CONFIG ───────────────────────────────────────────────────
INPUT_FILE  = "../stage2_eda/clean_data.csv"
OUTPUT_FILE = "features.csv"
FORM_WINDOW = 5     # how many past games to look at for form

# ─── LOAD ─────────────────────────────────────────────────────
print("[1/5] Loading clean data...")
df = pd.read_csv(INPUT_FILE)
df["Date"] = pd.to_datetime(df["Date"])
df = df.sort_values("Date").reset_index(drop=True)
print(f"      Rows: {len(df)}")

# ─── HELPER: rolling team stats ──────────────────────────────
def get_team_form(df, team, before_date, n=5):
    """
    Returns goals for, goals against, wins for a team
    in their last N matches before a given date.
    Looks at both home and away matches.
    """
    past = df[
        (df["Date"] < before_date) &
        ((df["HomeTeam"] == team) | (df["AwayTeam"] == team))
    ].tail(n)

    if len(past) == 0:
        return 0, 0, 0, 0    # gf, ga, wins, pts

    gf = ga = wins = 0
    for _, row in past.iterrows():
        if row["HomeTeam"] == team:
            gf += row["FTHG"]; ga += row["FTAG"]
            if row["FTR"] == "H": wins += 1
        else:
            gf += row["FTAG"]; ga += row["FTHG"]
            if row["FTR"] == "A": wins += 1

    pts = wins * 3
    return gf, ga, wins, pts

# ─── HELPER: head-to-head record ──────────────────────────────
def get_h2h(df, home_team, away_team, before_date):
    """
    Returns how many times home team won, drew, lost
    in ALL previous meetings between the two teams.
    """
    past = df[
        (df["Date"] < before_date) &
        (
            ((df["HomeTeam"]==home_team) & (df["AwayTeam"]==away_team)) |
            ((df["HomeTeam"]==away_team) & (df["AwayTeam"]==home_team))
        )
    ]
    if len(past) == 0:
        return 0, 0, 0    # home_wins, draws, away_wins

    home_wins = draws = away_wins = 0
    for _, row in past.iterrows():
        if row["HomeTeam"] == home_team:
            if   row["FTR"] == "H": home_wins += 1
            elif row["FTR"] == "D": draws     += 1
            else:                    away_wins += 1
        else:
            if   row["FTR"] == "A": home_wins += 1
            elif row["FTR"] == "D": draws     += 1
            else:                    away_wins += 1

    return home_wins, draws, away_wins

# ─── STEP 2: Build feature rows ───────────────────────────────
print(f"[2/5] Engineering features (this takes ~3–5 minutes)...")

records = []
total = len(df)

for i, row in df.iterrows():
    if i % 500 == 0:
        print(f"      Progress: {i}/{total} rows done...")

    home  = row["HomeTeam"]
    away  = row["AwayTeam"]
    date  = row["Date"]

    # Home team form
    hgf, hga, hwins, hpts = get_team_form(df, home, date, FORM_WINDOW)
    # Away team form
    agf, aga, awins, apts = get_team_form(df, away, date, FORM_WINDOW)
    # Head to head
    h2h_hw, h2h_d, h2h_aw = get_h2h(df, home, away, date)

    records.append({
        # Identifiers
        "Date"           : date,
        "HomeTeam"       : home,
        "AwayTeam"       : away,
        # Raw match info kept for reference
        "FTHG"           : row["FTHG"],
        "FTAG"           : row["FTAG"],
        # Target variable
        "FTR"            : row["FTR"],
        # ── Home form features ──
        "home_form_gf"   : hgf,
        "home_form_ga"   : hga,
        "home_form_wins" : hwins,
        "home_form_pts"  : hpts,
        "home_goal_diff" : hgf - hga,
        # ── Away form features ──
        "away_form_gf"   : agf,
        "away_form_ga"   : aga,
        "away_form_wins" : awins,
        "away_form_pts"  : apts,
        "away_goal_diff" : agf - aga,
        # ── Head-to-head features ──
        "h2h_home_wins"  : h2h_hw,
        "h2h_draws"      : h2h_d,
        "h2h_away_wins"  : h2h_aw,
    })

# ─── STEP 3: Create dataframe ─────────────────────────────────
print("[3/5] Building dataframe...")
features_df = pd.DataFrame(records)
print(f"      Shape: {features_df.shape}")
print(f"      Columns: {list(features_df.columns)}")

# ─── STEP 4: Check for nulls ──────────────────────────────────
print("[4/5] Null check:")
print(features_df.isnull().sum())

# ─── STEP 5: Save ─────────────────────────────────────────────
features_df.to_csv(OUTPUT_FILE, index=False)
print(f"[5/5] Saved → {OUTPUT_FILE}")

print("\nFeature summary:")
print(features_df.describe().round(2).to_string())
print("\n✓  Stage 3 complete. Run stage4_models/train_models.py next.")
