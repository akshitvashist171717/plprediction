"""
=============================================================
 STAGE 1 — Data Collection & Loading
 Language : Python
 Run      : python load_data.py
 Purpose  : Download, merge, and save all Premier League CSVs
=============================================================
"""

import pandas as pd
import os
import urllib.request

# ─── CONFIG ──────────────────────────────────────────────────
DATA_DIR    = "raw"          # folder where CSVs are saved
OUTPUT_FILE = "merged.csv"   # final merged file

# Seasons to download from football-data.co.uk
# Format: (start_year_2digit, end_year_2digit)
SEASONS = [
    ("1011","1112","1213","1314","1415",
     "1516","1617","1718","1819","1920",
     "2021","2122","2223","2324")
]
SEASONS = ["1011","1112","1213","1314","1415",
           "1516","1617","1718","1819","1920",
           "2021","2122","2223","2324"]

BASE_URL = "https://www.football-data.co.uk/mmz4281/{season}/E0.csv"

# ─── STEP 1: Create folder ───────────────────────────────────
os.makedirs(DATA_DIR, exist_ok=True)
print(f"[1/4] Folder '{DATA_DIR}' ready")

# ─── STEP 2: Download each season CSV ────────────────────────
print("[2/4] Downloading season CSVs...")
print("      (If download fails, manually save files to the 'raw' folder)")

for season in SEASONS:
    url      = BASE_URL.format(season=season)
    savepath = os.path.join(DATA_DIR, f"E0_{season}.csv")

    if os.path.exists(savepath):
        print(f"      Already exists: {savepath}")
        continue

    try:
        urllib.request.urlretrieve(url, savepath)
        print(f"      Downloaded : {savepath}")
    except Exception as e:
        print(f"      FAILED {season}: {e}  — place manually in {DATA_DIR}/")

# ─── STEP 3: Merge all CSVs ──────────────────────────────────
print("[3/4] Merging all CSV files...")

all_frames = []
for filename in sorted(os.listdir(DATA_DIR)):
    if not filename.endswith(".csv"):
        continue
    filepath = os.path.join(DATA_DIR, filename)
    try:
        df = pd.read_csv(filepath, encoding="latin1", low_memory=False)
        df["season_file"] = filename      # track which file it came from
        all_frames.append(df)
        print(f"      Loaded: {filename}  ({len(df)} rows)")
    except Exception as e:
        print(f"      Error reading {filename}: {e}")

if not all_frames:
    raise RuntimeError("No CSV files found! Place season CSVs inside the 'raw' folder.")

merged = pd.concat(all_frames, ignore_index=True)
print(f"\n      Total rows after merge: {len(merged)}")
print(f"      Columns: {list(merged.columns[:10])} ...")

# ─── STEP 4: Save merged file ─────────────────────────────────
merged.to_csv(OUTPUT_FILE, index=False)
print(f"[4/4] Saved → {OUTPUT_FILE}")
print("\n✓  Stage 1 complete. Run stage2_eda/eda.py next.")
