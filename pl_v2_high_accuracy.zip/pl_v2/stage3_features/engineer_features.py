"""
=============================================================
 STAGE 3 — Advanced Feature Engineering (HIGH ACCURACY)
 Language : Python
 Run      : python engineer_features.py
 Input    : ../stage2_eda/clean_data.csv
 Output   : features.csv
=============================================================

ADVANCED FEATURES CREATED (35 total):
  Form features    : rolling 5 & 10 game windows
  Efficiency ratios: shots-on-target ratio, conversion rate
  Season stats     : cumulative points, position proxy
  Momentum         : weighted recent form (exponential decay)
  H2H              : head-to-head record, goal difference
  Discipline       : cards per game
  Home advantage   : explicit home/away form separation
"""
import pandas as pd
import numpy  as np
import os, sys

# ── Auto-find input file ──────────────────────────────────────
def find_file(filename):
    search = [
        filename,
        f"../{filename}",
        f"stage2_eda/{filename}",
        f"../stage2_eda/{filename}",
        os.path.join(os.path.expanduser("~"), "pl_v2", "stage2_eda", filename),
        os.path.join(os.path.expanduser("~"), "Desktop", "pl_v2", "stage2_eda", filename),
        os.path.join(os.path.expanduser("~"), "Downloads","pl_v2","stage2_eda",filename),
    ]
    for p in search:
        if os.path.exists(p):
            return os.path.abspath(p)
    # full home search
    for root, dirs, files in os.walk(os.path.expanduser("~")):
        dirs[:] = [d for d in dirs if d not in ["AppData",".git","node_modules","__pycache__"]]
        if filename in files:
            return os.path.join(root, filename)
    return None

INPUT_FILE  = find_file("clean_data.csv")
OUTPUT_FILE = os.path.join(os.getcwd(), "features.csv")

if INPUT_FILE is None:
    print("✗ clean_data.csv not found — run stage2_eda/eda.py first")
    sys.exit(1)

print(f"[1/6] Loading: {INPUT_FILE}")
df = pd.read_csv(INPUT_FILE)
df["Date"] = pd.to_datetime(df["Date"])
df = df.sort_values("Date").reset_index(drop=True)
df["FTHG"] = pd.to_numeric(df["FTHG"], errors="coerce").fillna(0)
df["FTAG"] = pd.to_numeric(df["FTAG"], errors="coerce").fillna(0)
for col in ["HS","AS","HST","AST","HC","AC","HY","AY","HR","AR"]:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
print(f"      Rows: {len(df)}")

# ── Helper: rolling team stats (flexible window) ─────────────
def team_rolling(df, team, before_date, n=5):
    """All matches (home+away) for a team before a date."""
    mask = (df["Date"] < before_date) & \
           ((df["HomeTeam"]==team)|(df["AwayTeam"]==team))
    past = df[mask].tail(n)
    if len(past) == 0:
        return dict(gf=0,ga=0,wins=0,draws=0,pts=0,
                    shots=0,shots_ot=0,corners=0,cards=0)
    gf=ga=wins=draws=shots=shots_ot=corners=cards=0
    for _,r in past.iterrows():
        if r["HomeTeam"]==team:
            gf+=r["FTHG"]; ga+=r["FTAG"]
            shots   +=r.get("HS",0); shots_ot+=r.get("HST",0)
            corners +=r.get("HC",0); cards   +=r.get("HY",0)+r.get("HR",0)*3
            if r["FTR"]=="H": wins+=1
            elif r["FTR"]=="D": draws+=1
        else:
            gf+=r["FTAG"]; ga+=r["FTHG"]
            shots   +=r.get("AS",0); shots_ot+=r.get("AST",0)
            corners +=r.get("AC",0); cards   +=r.get("AY",0)+r.get("AR",0)*3
            if r["FTR"]=="A": wins+=1
            elif r["FTR"]=="D": draws+=1
    return dict(gf=gf,ga=ga,wins=wins,draws=draws,
                pts=wins*3+draws,shots=shots,
                shots_ot=shots_ot,corners=corners,cards=cards)

def home_rolling(df, team, before_date, n=5):
    """Home-only matches."""
    past = df[(df["Date"]<before_date)&(df["HomeTeam"]==team)].tail(n)
    if len(past)==0: return dict(gf=0,ga=0,wins=0,pts=0)
    gf=ga=wins=0
    for _,r in past.iterrows():
        gf+=r["FTHG"]; ga+=r["FTAG"]
        if r["FTR"]=="H": wins+=1
    return dict(gf=gf,ga=ga,wins=wins,pts=wins*3+(len(past)-wins-sum(1 for _,r in past.iterrows() if r["FTR"]=="A"))*1)

def away_rolling(df, team, before_date, n=5):
    """Away-only matches."""
    past = df[(df["Date"]<before_date)&(df["AwayTeam"]==team)].tail(n)
    if len(past)==0: return dict(gf=0,ga=0,wins=0,pts=0)
    gf=ga=wins=0
    for _,r in past.iterrows():
        gf+=r["FTAG"]; ga+=r["FTHG"]
        if r["FTR"]=="A": wins+=1
    return dict(gf=gf,ga=ga,wins=wins,pts=wins*3)

def weighted_form(df, team, before_date, n=7):
    """Exponentially weighted points (recent games matter more)."""
    mask = (df["Date"]<before_date) & \
           ((df["HomeTeam"]==team)|(df["AwayTeam"]==team))
    past = df[mask].tail(n)
    if len(past)==0: return 0.0
    weights = np.exp(np.linspace(-1,0,len(past)))
    weights /= weights.sum()
    pts_list=[]
    for _,r in past.iterrows():
        if r["HomeTeam"]==team:
            if r["FTR"]=="H": pts_list.append(3)
            elif r["FTR"]=="D": pts_list.append(1)
            else: pts_list.append(0)
        else:
            if r["FTR"]=="A": pts_list.append(3)
            elif r["FTR"]=="D": pts_list.append(1)
            else: pts_list.append(0)
    return float(np.dot(np.array(pts_list), weights))

def get_h2h(df, home, away, before_date):
    mask = (df["Date"]<before_date) & (
        ((df["HomeTeam"]==home)&(df["AwayTeam"]==away)) |
        ((df["HomeTeam"]==away)&(df["AwayTeam"]==home)))
    past = df[mask]
    if len(past)==0: return 0,0,0,0.0,0.0
    hw=draws=aw=hgf=hga=0
    for _,r in past.iterrows():
        if r["HomeTeam"]==home:
            hgf+=r["FTHG"]; hga+=r["FTAG"]
            if r["FTR"]=="H": hw+=1
            elif r["FTR"]=="D": draws+=1
            else: aw+=1
        else:
            hgf+=r["FTAG"]; hga+=r["FTHG"]
            if r["FTR"]=="A": hw+=1
            elif r["FTR"]=="D": draws+=1
            else: aw+=1
    total=len(past)
    return hw, draws, aw, hgf/total, hga/total

def season_points(df, team, season, before_date):
    """Cumulative points in current season."""
    mask = (df["season"]==season)&(df["Date"]<before_date)& \
           ((df["HomeTeam"]==team)|(df["AwayTeam"]==team))
    past = df[mask]
    pts=0
    for _,r in past.iterrows():
        if r["HomeTeam"]==team:
            if r["FTR"]=="H": pts+=3
            elif r["FTR"]=="D": pts+=1
        else:
            if r["FTR"]=="A": pts+=3
            elif r["FTR"]=="D": pts+=1
    return pts

# ── Main loop ──────────────────────────────────────────────────
print("[2/6] Building advanced features (8-12 mins for full dataset)...")
print("      Please wait — progress shown every 300 rows\n")

records=[]
total=len(df)

for i,row in df.iterrows():
    if i%300==0:
        pct=round(i/total*100,1)
        print(f"      [{i}/{total}]  {pct}%")

    home  = row["HomeTeam"]
    away  = row["AwayTeam"]
    date  = row["Date"]
    season= row.get("season","")

    # 5-game rolling (overall)
    h5  = team_rolling(df,home,date,5)
    a5  = team_rolling(df,away,date,5)
    # 10-game rolling (overall)
    h10 = team_rolling(df,home,date,10)
    a10 = team_rolling(df,away,date,10)
    # Home-specific form
    hh5 = home_rolling(df,home,date,5)
    # Away-specific form
    aa5 = away_rolling(df,away,date,5)
    # Weighted (momentum)
    h_wf= weighted_form(df,home,date,7)
    a_wf= weighted_form(df,away,date,7)
    # H2H
    h2h_hw,h2h_d,h2h_aw,h2h_gf,h2h_ga = get_h2h(df,home,away,date)
    # Season points
    h_spts = season_points(df,home,season,date)
    a_spts = season_points(df,away,season,date)

    # Derived ratios (avoid div-by-zero)
    h_sot_r  = h5["shots_ot"]/max(h5["shots"],1)
    a_sot_r  = a5["shots_ot"]/max(a5["shots"],1)
    h_conv_r = h5["gf"]/max(h5["shots_ot"],1)
    a_conv_r = a5["gf"]/max(a5["shots_ot"],1)
    h2h_total= h2h_hw+h2h_d+h2h_aw

    records.append({
        # identifiers
        "Date":date,"HomeTeam":home,"AwayTeam":away,
        "FTHG":row["FTHG"],"FTAG":row["FTAG"],"FTR":row["FTR"],
        # ── 5-game overall form ──
        "h_form5_gf"     : h5["gf"],
        "h_form5_ga"     : h5["ga"],
        "h_form5_wins"   : h5["wins"],
        "h_form5_pts"    : h5["pts"],
        "h_form5_gd"     : h5["gf"]-h5["ga"],
        "a_form5_gf"     : a5["gf"],
        "a_form5_ga"     : a5["ga"],
        "a_form5_wins"   : a5["wins"],
        "a_form5_pts"    : a5["pts"],
        "a_form5_gd"     : a5["gf"]-a5["ga"],
        # ── 10-game overall form ──
        "h_form10_pts"   : h10["pts"],
        "h_form10_gd"    : h10["gf"]-h10["ga"],
        "a_form10_pts"   : a10["pts"],
        "a_form10_gd"    : a10["gf"]-a10["ga"],
        # ── Home/Away specific form ──
        "h_home5_wins"   : hh5["wins"],
        "h_home5_pts"    : hh5["pts"],
        "h_home5_gd"     : hh5["gf"]-hh5["ga"],
        "a_away5_wins"   : aa5["wins"],
        "a_away5_pts"    : aa5["pts"],
        "a_away5_gd"     : aa5["gf"]-aa5["ga"],
        # ── Weighted momentum ──
        "h_momentum"     : h_wf,
        "a_momentum"     : a_wf,
        "momentum_diff"  : h_wf - a_wf,
        # ── Efficiency ratios ──
        "h_sot_ratio"    : h_sot_r,
        "a_sot_ratio"    : a_sot_r,
        "h_conv_ratio"   : h_conv_r,
        "a_conv_ratio"   : a_conv_r,
        "h_corners5"     : h5["corners"],
        "a_corners5"     : a5["corners"],
        # ── Discipline ──
        "h_cards5"       : h5["cards"],
        "a_cards5"       : a5["cards"],
        # ── Season position proxy ──
        "h_season_pts"   : h_spts,
        "a_season_pts"   : a_spts,
        "season_pts_diff": h_spts - a_spts,
        # ── Head-to-head ──
        "h2h_home_wins"  : h2h_hw,
        "h2h_draws"      : h2h_d,
        "h2h_away_wins"  : h2h_aw,
        "h2h_home_winr"  : h2h_hw/max(h2h_total,1),
        "h2h_avg_gf"     : h2h_gf,
        "h2h_avg_ga"     : h2h_ga,
    })

print(f"\n[3/6] Building dataframe...")
feat = pd.DataFrame(records)
print(f"      Shape: {feat.shape}")

print("[4/6] Null check:")
nulls = feat.isnull().sum()
print("      No nulls" if nulls.sum()==0 else nulls[nulls>0])

feat.to_csv(OUTPUT_FILE, index=False)
print(f"[5/6] Saved → {OUTPUT_FILE}")
print(f"\n✓  Stage 3 complete — {len(feat)} rows, {feat.shape[1]} columns")
print("   Run stage4_models/train_models.py next.")
