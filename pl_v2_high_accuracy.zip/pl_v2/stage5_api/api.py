"""
STAGE 5 — REST API  (6 Models including Stacking Ensemble)
Language : Python (Flask)
Run      : python api.py
Install  : pip install flask flask-cors
"""
from flask      import Flask, request, jsonify
from flask_cors import CORS
import pickle, json, numpy as np, pandas as pd, os, sys

app = Flask(__name__)
CORS(app)

def find_dir(name):
    paths = [name, f"../{name}",
             f"stage4_models/{name}", f"../stage4_models/{name}",
             os.path.join(os.path.expanduser("~"),"pl_v2","stage4_models",name),
             os.path.join(os.path.expanduser("~"),"Desktop","pl_v2","stage4_models",name)]
    for p in paths:
        if os.path.exists(p): return os.path.abspath(p)
    return None

MODELS_DIR = find_dir("models")
if not MODELS_DIR:
    print("✗ models/ folder not found — run stage4_models/train_models.py first")
    sys.exit(1)

print(f"Loading models from: {MODELS_DIR}")

MODEL_FILES = {"lr":"Logistic Regression","knn":"K-Nearest Neighbors",
               "dt":"Decision Tree","rf":"Random Forest",
               "xgb":"XGBoost","stack":"Stacking Ensemble"}
SCALED = {"lr","knn"}

loaded = {}
for short,name in MODEL_FILES.items():
    path = f"{MODELS_DIR}/{short}.pkl"
    if os.path.exists(path):
        with open(path,"rb") as f: loaded[short]=pickle.load(f)
        print(f"  ✓ {name}")
    else:
        print(f"  ✗ {name} — not found")

with open(f"{MODELS_DIR}/label_encoder.pkl","rb") as f: le     = pickle.load(f)
with open(f"{MODELS_DIR}/scaler.pkl","rb")         as f: scaler = pickle.load(f)
with open(f"{MODELS_DIR}/model_results.json","r")  as f: info   = json.load(f)

FEATURE_COLS = info["feature_cols"]
print(f"\n✓ Ready — {len(loaded)} models loaded on http://localhost:5000\n")

@app.route("/health",methods=["GET"])
def health():
    return jsonify({"status":"ok","models":list(loaded.keys())})

@app.route("/models",methods=["GET"])
def models():
    out={}
    for short,name in MODEL_FILES.items():
        if name in info and isinstance(info[name],dict):
            out[short]={"name":name,**info[name]}
    return jsonify(out)

@app.route("/teams",methods=["GET"])
def teams():
    try:
        clean_path = None
        for p in ["../stage2_eda/clean_data.csv",
                  os.path.join(os.path.expanduser("~"),"pl_v2","stage2_eda","clean_data.csv"),
                  os.path.join(os.path.expanduser("~"),"Desktop","pl_v2","stage2_eda","clean_data.csv")]:
            if os.path.exists(p): clean_path=p; break
        if clean_path:
            df=pd.read_csv(clean_path)
            all_t=sorted(set(df.HomeTeam.dropna())|set(df.AwayTeam.dropna()))
            return jsonify({"teams":all_t})
    except: pass
    fallback=["Arsenal","Aston Villa","Brentford","Brighton","Burnley","Chelsea",
              "Crystal Palace","Everton","Fulham","Leeds United","Leicester City",
              "Liverpool","Manchester City","Manchester United","Newcastle United",
              "Norwich City","Sheffield United","Southampton","Tottenham Hotspur",
              "Watford","West Ham United","Wolves"]
    return jsonify({"teams":fallback})

@app.route("/predict",methods=["POST"])
def predict():
    try:
        data      = request.get_json()
        model_key = data.get("model","xgb").lower()
        if model_key not in loaded:
            return jsonify({"error":f"Model '{model_key}' not loaded"}),400
        model = loaded[model_key]
        row   = []
        for col in FEATURE_COLS:
            v = data.get(col)
            if v is None: return jsonify({"error":f"Missing: {col}"}),400
            row.append(float(v))
        X = np.array([row])
        if model_key in SCALED: X = scaler.transform(X)
        pred   = model.predict(X)[0]
        proba  = model.predict_proba(X)[0]
        label  = le.inverse_transform([pred])[0]
        classes= le.classes_
        probs  = {c:round(float(p)*100,1) for c,p in zip(classes,proba)}
        name   = MODEL_FILES[model_key]
        model_info = info.get(name,{})
        return jsonify({
            "prediction"    : label,
            "result_text"   : {"H":f"Home Win — {data.get('home_team','')}",
                                "D":"Draw",
                                "A":f"Away Win — {data.get('away_team','')}"}[label],
            "probabilities" : probs,
            "model_used"    : name,
            "accuracy"      : model_info.get("acc","N/A") if isinstance(model_info,dict) else "N/A",
            "f1"            : model_info.get("f1","N/A") if isinstance(model_info,dict) else "N/A",
        })
    except Exception as e:
        return jsonify({"error":str(e)}),500

@app.route("/predict_all",methods=["POST"])
def predict_all():
    try:
        data = request.get_json()
        row  = []
        for col in FEATURE_COLS:
            v=data.get(col)
            if v is None: return jsonify({"error":f"Missing: {col}"}),400
            row.append(float(v))
        X_raw = np.array([row])
        X_sc  = scaler.transform(X_raw)
        out   = {}
        for short,name in MODEL_FILES.items():
            if short not in loaded: continue
            X     = X_sc if short in SCALED else X_raw
            pred  = loaded[short].predict(X)[0]
            proba = loaded[short].predict_proba(X)[0]
            label = le.inverse_transform([pred])[0]
            probs = {c:round(float(p)*100,1) for c,p in zip(le.classes_,proba)}
            mi    = info.get(name,{})
            out[short]={"name":name,"prediction":label,"probabilities":probs,
                        "accuracy":mi.get("acc","N/A") if isinstance(mi,dict) else "N/A"}
        return jsonify({"models":out})
    except Exception as e:
        return jsonify({"error":str(e)}),500

if __name__=="__main__":
    print("─"*50)
    print("  PL Predictor API — High Accuracy Version")
    print("  http://localhost:5000")
    print("  POST /predict      single model")
    print("  POST /predict_all  all 6 models")
    print("─"*50)
    app.run(debug=True,port=5000)
