"""
STAGE 1 — Data Collection
Run: python load_data.py
"""
import pandas as pd, os, urllib.request

DATA_DIR = "raw"; OUTPUT = "merged.csv"
SEASONS  = ["1011","1112","1213","1314","1415","1516",
            "1617","1718","1819","1920","2021","2122","2223","2324"]
BASE_URL = "https://www.football-data.co.uk/mmz4281/{s}/E0.csv"

os.makedirs(DATA_DIR, exist_ok=True)
frames = []
for s in SEASONS:
    path = f"{DATA_DIR}/E0_{s}.csv"
    if not os.path.exists(path):
        try:
            urllib.request.urlretrieve(BASE_URL.format(s=s), path)
            print(f"  Downloaded {s}")
        except Exception as e:
            print(f"  FAILED {s}: {e}")
    if os.path.exists(path):
        df = pd.read_csv(path, encoding="latin1", low_memory=False)
        df["season"] = s
        frames.append(df)

merged = pd.concat(frames, ignore_index=True)
merged.to_csv(OUTPUT, index=False)
print(f"✓ Merged {len(merged)} rows → {OUTPUT}")
