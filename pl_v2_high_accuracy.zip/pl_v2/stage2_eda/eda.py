"""
STAGE 2 — EDA & Cleaning
Run: python eda.py
Input:  ../stage1_data/merged.csv
Output: clean_data.csv + plots/
"""
import pandas as pd, matplotlib.pyplot as plt, seaborn as sns, os

INPUT  = "../stage1_data/merged.csv"
OUTPUT = "clean_data.csv"
os.makedirs("plots", exist_ok=True)
sns.set_theme(style="whitegrid")

df = pd.read_csv(INPUT, encoding="latin1", low_memory=False)
COLS = ["Date","HomeTeam","AwayTeam","FTHG","FTAG","FTR",
        "HS","AS","HST","AST","HC","AC","HY","AY","HR","AR","season"]
df = df[[c for c in COLS if c in df.columns]].copy()
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True, errors="coerce")
df = df.dropna(subset=["FTR","HomeTeam","AwayTeam","FTHG","FTAG","Date"])
df = df[df["FTR"].isin(["H","D","A"])].fillna(0)
df = df.sort_values("Date").reset_index(drop=True)
df["Year"] = df["Date"].dt.year
df.to_csv(OUTPUT, index=False)
print(f"✓ Clean data: {df.shape} → {OUTPUT}")

# Chart 1: outcome distribution
counts = df["FTR"].value_counts()
plt.figure(figsize=(7,5))
plt.pie([counts.get("H",0),counts.get("D",0),counts.get("A",0)],
        labels=["Home Win","Draw","Away Win"],
        colors=["#38bdf8","#facc15","#818cf8"],autopct="%1.1f%%",startangle=140,
        wedgeprops=dict(linewidth=1.5,edgecolor="white"))
plt.title("Match Outcome Distribution",fontsize=14,fontweight="bold")
plt.tight_layout(); plt.savefig("plots/01_outcomes.png",dpi=150); plt.close()

# Chart 2: goals over time
yr = df.groupby("Year")[["FTHG","FTAG"]].mean().reset_index()
yr = yr[(yr.Year>=2011)&(yr.Year<=2024)]
plt.figure(figsize=(10,5))
plt.plot(yr.Year,yr.FTHG,marker="o",color="#38bdf8",label="Home Goals",linewidth=2)
plt.plot(yr.Year,yr.FTAG,marker="s",color="#818cf8",label="Away Goals",linewidth=2)
plt.title("Avg Goals Per Match by Year",fontsize=14,fontweight="bold")
plt.legend(); plt.xticks(rotation=45); plt.tight_layout()
plt.savefig("plots/02_goals_time.png",dpi=150); plt.close()

# Chart 3: top teams
hw = df[df.FTR=="H"].groupby("HomeTeam").size()
aw = df[df.FTR=="A"].groupby("AwayTeam").size()
tot = hw.add(aw,fill_value=0).sort_values(ascending=False).head(10)
plt.figure(figsize=(10,5))
bars=plt.bar(tot.index,tot.values,color="#38bdf8",edgecolor="white")
plt.bar_label(bars,padding=3,fontsize=10)
plt.title("Top 10 Teams by Total Wins",fontsize=14,fontweight="bold")
plt.xticks(rotation=30,ha="right"); plt.tight_layout()
plt.savefig("plots/03_top_teams.png",dpi=150); plt.close()
print("✓ Plots saved")
