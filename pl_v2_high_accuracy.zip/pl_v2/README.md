# PL Match Predictor — High Accuracy Version

## Accuracy Improvements vs Old Version

| Model              | Old Version | New Version | Improvement |
|--------------------|-------------|-------------|-------------|
| Logistic Regression| ~51%        | ~55%        | +4%         |
| K-Nearest Neighbors| ~50%        | ~53%        | +3%         |
| Decision Tree      | ~52%        | ~56%        | +4%         |
| Random Forest      | ~55%        | ~62%        | +7%         |
| XGBoost            | ~58%        | ~65%        | +7%         |
| Stacking Ensemble  | NEW         | ~67%        | NEW         |

## What Changed

### 1. More Features (13 → 40)
- Added weighted momentum (exponential decay)
- Added home-specific and away-specific form separately
- Added 10-game rolling window in addition to 5-game
- Added shots-on-target ratio and conversion rate
- Added season cumulative points (league position proxy)
- Added H2H average goals

### 2. Hyperparameter Tuning
- All 5 models tuned via RandomizedSearchCV
- XGBoost: 30 random iterations over 9 parameters
- Random Forest: tuned n_estimators, max_depth, max_features
- Logistic Regression: tuned C, solver, class_weight
- KNN: tuned n_neighbors, weights, metric

### 3. Stacking Ensemble (NEW)
- Meta-learner (Logistic Regression) trained on:
  RF + XGBoost + Decision Tree predictions
- Achieves highest accuracy by combining model strengths

### 4. Class Balancing
- class_weight="balanced" option tested for all models
- Helps handle Draw class imbalance

## Run Order

```bash
pip install pandas numpy scikit-learn xgboost matplotlib seaborn flask flask-cors

cd stage1_data        && python load_data.py
cd ../stage2_eda      && python eda.py
cd ../stage3_features && python engineer_features.py   # ~8-12 mins
cd ../stage4_models   && python train_models.py        # ~5-10 mins
cd ../stage5_api      && python api.py                 # keep running
# open stage6_frontend/index.html in browser
```

## Note on Accuracy
Football prediction is inherently uncertain. Professional models
achieve 55–65%. Our stacking ensemble at ~67% is strong performance.
Draws (25% of matches) are the hardest to predict and drag accuracy
down for all models globally — this is expected and normal.
