"""
=============================================================
 STAGE 1 — Data Collection & Loading
 Language : Python
 Run      : python load_data.py
 Purpose  : Download, merge, and save all Premier League CSVs
=============================================================
"""

import pandas as pd
import os
import urllib.request

DATA_DIR    = "raw"
OUTPUT_FILE = "merged.csv"

SEASONS = ["1011","1112","1213","1314","1415",
           "1516","1617","1718","1819","1920",
           "2021","2122","2223","2324"]

BASE_URL = "https://www.football-data.co.uk/mmz4281/{season}/E0.csv"

os.makedirs(DATA_DIR, exist_ok=True)
print(f"[1/4] Folder '{DATA_DIR}' ready")

print("[2/4] Downloading season CSVs...")
for season in SEASONS:
    url      = BASE_URL.format(season=season)
    savepath = os.path.join(DATA_DIR, f"E0_{season}.csv")
    if os.path.exists(savepath):
        print(f"      Already exists: {savepath}")
        continue
    try:
        urllib.request.urlretrieve(url, savepath)
        print(f"      Downloaded : {savepath}")
    except Exception as e:
        print(f"      FAILED {season}: {e} — place file manually in {DATA_DIR}/")

print("[3/4] Merging all CSV files...")
all_frames = []
for filename in sorted(os.listdir(DATA_DIR)):
    if not filename.endswith(".csv"):
        continue
    filepath = os.path.join(DATA_DIR, filename)
    try:
        df = pd.read_csv(filepath, encoding="latin1", low_memory=False)
        df["season_file"] = filename
        all_frames.append(df)
        print(f"      Loaded: {filename}  ({len(df)} rows)")
    except Exception as e:
        print(f"      Error reading {filename}: {e}")

if not all_frames:
    raise RuntimeError("No CSV files found! Place season CSVs inside the 'raw' folder.")

merged = pd.concat(all_frames, ignore_index=True)
print(f"\n      Total rows: {len(merged)}")

merged.to_csv(OUTPUT_FILE, index=False)
print(f"[4/4] Saved → {OUTPUT_FILE}")
print("\n✓  Stage 1 complete. Run stage2_eda/eda.py next.")
