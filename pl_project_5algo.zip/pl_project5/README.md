# Premier League Match Predictor — 5 Algorithm Version

## 5 ML Algorithms Used

| # | Algorithm           | Type              | Accuracy |
|---|---------------------|-------------------|----------|
| 1 | Logistic Regression | Linear Classifier | ~51%     |
| 2 | K-Nearest Neighbors | Instance-based    | ~50%     |
| 3 | Decision Tree       | Rule-based Tree   | ~52%     |
| 4 | Random Forest       | Ensemble Trees    | ~55%     |
| 5 | XGBoost             | Gradient Boosting | ~58%     |

---

## Project Structure

```
pl_project5/
├── stage1_data/
│   └── load_data.py              Python — download + merge CSVs
├── stage2_eda/
│   └── eda.py                    Python — clean data + 5 charts
├── stage3_features/
│   └── engineer_features.py      Python — rolling form, H2H features
├── stage4_models/
│   └── train_models.py           Python — train ALL 5 models
├── stage5_evaluation/
│   └── api.py                    Python/Flask — REST API (5 models)
└── stage6_frontend/
    ├── index.html                HTML — page structure
    ├── css/style.css             CSS — styling
    └── js/app.js                 JavaScript — UI + API calls
```

---

## How to Run

### Install (once only)
```bash
pip install pandas numpy scikit-learn xgboost matplotlib seaborn flask flask-cors
```

### Run each stage in order
```bash
cd stage1_data        && python load_data.py
cd ../stage2_eda      && python eda.py
cd ../stage3_features && python engineer_features.py
cd ../stage4_models   && python train_models.py
cd ../stage5_evaluation && python api.py   # keep running
```

Then open stage6_frontend/index.html in your browser.

---

## New Features vs 3-Algorithm Version

- Added K-Nearest Neighbors and Decision Tree algorithms
- "Run all 5 at once" button — shows all predictions side by side
- Consensus prediction — majority vote across all 5 models
- F1 score displayed alongside accuracy
- CV boxplot chart showing stability of each model
- Per-model colour coding throughout the UI
- /predict_all API endpoint for batch predictions
