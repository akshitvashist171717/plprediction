"""
=============================================================
 STAGE 4 — Model Training  (5 Algorithms)
 Language : Python
 Run      : python train_models.py
 Input    : ../stage3_features/features.csv
 Output   : models/ folder  +  plots/ folder
=============================================================

5 ALGORITHMS USED:
  1. Logistic Regression     — linear baseline, fast & interpretable
  2. K-Nearest Neighbors     — predicts by finding similar past matches
  3. Decision Tree           — learns if/else rules from data
  4. Random Forest           — 200 decision trees voting together
  5. XGBoost                 — boosted trees, best overall performer
"""

import pandas as pd
import numpy  as np
import pickle, json, os

from sklearn.model_selection  import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing    import LabelEncoder, StandardScaler
from sklearn.linear_model     import LogisticRegression
from sklearn.neighbors        import KNeighborsClassifier
from sklearn.tree             import DecisionTreeClassifier
from sklearn.ensemble         import RandomForestClassifier
from sklearn.metrics          import (accuracy_score, classification_report,
                                       confusion_matrix, f1_score)
from xgboost                  import XGBClassifier
import matplotlib.pyplot      as plt
import matplotlib.gridspec    as gridspec
import seaborn                as sns

# ─── CONFIG ───────────────────────────────────────────────────
INPUT_FILE  = "../stage3_features/features.csv"
MODELS_DIR  = "models"
PLOTS_DIR   = "plots"
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(PLOTS_DIR,  exist_ok=True)

FEATURE_COLS = [
    "home_form_gf",   "home_form_ga",
    "home_form_wins", "home_form_pts",
    "home_goal_diff",
    "away_form_gf",   "away_form_ga",
    "away_form_wins", "away_form_pts",
    "away_goal_diff",
    "h2h_home_wins",  "h2h_draws",  "h2h_away_wins",
]

# ─── STEP 1: Load & prepare data ─────────────────────────────
print("=" * 58)
print("  PREMIER LEAGUE PREDICTOR — 5 ALGORITHM TRAINING")
print("=" * 58)

print("\n[1/8] Loading feature data...")
df = pd.read_csv(INPUT_FILE)
print(f"      Rows: {len(df)}  |  Features: {len(FEATURE_COLS)}")

X = df[FEATURE_COLS]
y = df["FTR"]

# Encode labels: A=0, D=1, H=2
le = LabelEncoder()
y_enc = le.fit_transform(y)
print(f"      Labels: {dict(zip(le.classes_, le.transform(le.classes_)))}")
print(f"      Class distribution: {pd.Series(y).value_counts().to_dict()}")

# ─── STEP 2: Train / test split ───────────────────────────────
print("\n[2/8] Splitting data 80% train / 20% test...")
X_train, X_test, y_train, y_test = train_test_split(
    X, y_enc, test_size=0.2, random_state=42, stratify=y_enc)
print(f"      Train: {len(X_train)}   Test: {len(X_test)}")

# Scale features (needed for LR and KNN)
scaler         = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled  = scaler.transform(X_test)
X_all_scaled   = scaler.transform(X)

# ─── STEP 3: Define all 5 models ──────────────────────────────
print("\n[3/8] Initialising 5 models...")

models_config = {
    "Logistic Regression": {
        "model"  : LogisticRegression(max_iter=2000, C=1.0, random_state=42),
        "scaled" : True,   # needs scaled input
        "color"  : "#64748b",
        "short"  : "lr",
    },
    "K-Nearest Neighbors": {
        "model"  : KNeighborsClassifier(n_neighbors=11, metric="euclidean"),
        "scaled" : True,   # needs scaled input
        "color"  : "#f97316",
        "short"  : "knn",
    },
    "Decision Tree": {
        "model"  : DecisionTreeClassifier(max_depth=8, min_samples_leaf=10,
                                           random_state=42),
        "scaled" : False,
        "color"  : "#22c55e",
        "short"  : "dt",
    },
    "Random Forest": {
        "model"  : RandomForestClassifier(n_estimators=200, max_depth=10,
                                           min_samples_leaf=5,
                                           random_state=42, n_jobs=-1),
        "scaled" : False,
        "color"  : "#818cf8",
        "short"  : "rf",
    },
    "XGBoost": {
        "model"  : XGBClassifier(n_estimators=300, max_depth=5,
                                  learning_rate=0.05, subsample=0.8,
                                  colsample_bytree=0.8,
                                  eval_metric="mlogloss",
                                  random_state=42, n_jobs=-1),
        "scaled" : False,
        "color"  : "#38bdf8",
        "short"  : "xgb",
    },
}

# ─── STEP 4: Train each model ─────────────────────────────────
print("\n[4/8] Training models...\n")
results = {}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

for name, cfg in models_config.items():
    print(f"   ── {name} ──────────────────────────────────────")
    m = cfg["model"]

    # Choose scaled or raw data
    Xtr = X_train_scaled if cfg["scaled"] else X_train
    Xte = X_test_scaled  if cfg["scaled"] else X_test
    Xal = X_all_scaled   if cfg["scaled"] else X

    # Train
    m.fit(Xtr, y_train)
    preds = m.predict(Xte)

    # Metrics
    acc  = accuracy_score(y_test, preds)
    f1   = f1_score(y_test, preds, average="weighted")

    # 5-fold cross validation
    cv_scores = cross_val_score(m, Xal, y_enc, cv=cv, scoring="accuracy", n_jobs=-1)
    cv_mean   = cv_scores.mean()
    cv_std    = cv_scores.std()

    print(f"      Test Accuracy  : {acc*100:.2f}%")
    print(f"      Weighted F1    : {f1:.4f}")
    print(f"      CV Accuracy    : {cv_mean*100:.2f}% ± {cv_std*100:.2f}%\n")

    results[name] = {
        "model"       : m,
        "preds"       : preds,
        "accuracy"    : round(acc * 100, 2),
        "f1"          : round(f1, 4),
        "cv_mean"     : round(cv_mean * 100, 2),
        "cv_std"      : round(cv_std  * 100, 2),
        "color"       : cfg["color"],
        "short"       : cfg["short"],
        "scaled"      : cfg["scaled"],
    }

# ─── STEP 5: Classification reports ──────────────────────────
print("[5/8] Classification Reports...\n")
for name, r in results.items():
    print(f"{'─'*50}")
    print(f"  {name}")
    print(f"{'─'*50}")
    print(classification_report(y_test, r["preds"], target_names=le.classes_))

# ─── STEP 6: Save models to disk ─────────────────────────────
print("[6/8] Saving models...")

for name, r in results.items():
    fname = f"{MODELS_DIR}/{r['short']}.pkl"
    with open(fname, "wb") as f:
        pickle.dump(r["model"], f)
    print(f"      Saved: {fname}")

with open(f"{MODELS_DIR}/label_encoder.pkl", "wb") as f: pickle.dump(le,     f)
with open(f"{MODELS_DIR}/scaler.pkl",        "wb") as f: pickle.dump(scaler, f)

# Save summary JSON for API + frontend
summary = {
    name: {
        "accuracy" : r["accuracy"],
        "f1"       : r["f1"],
        "cv_mean"  : r["cv_mean"],
        "cv_std"   : r["cv_std"],
        "short"    : r["short"],
        "color"    : r["color"],
    }
    for name, r in results.items()
}
summary["feature_cols"] = FEATURE_COLS

with open(f"{MODELS_DIR}/model_results.json", "w") as f:
    json.dump(summary, f, indent=2)

print(f"\n      All models + results saved to {MODELS_DIR}/")

# ─── STEP 7: Evaluation plots ────────────────────────────────
print("\n[7/8] Generating evaluation plots...")

# ── Plot 1: Accuracy comparison bar chart ────────────────────
names  = list(results.keys())
accs   = [r["accuracy"] for r in results.values()]
colors = [r["color"]    for r in results.values()]
cv_means = [r["cv_mean"] for r in results.values()]

fig, ax = plt.subplots(figsize=(11, 5))
x = np.arange(len(names))
w = 0.38
b1 = ax.bar(x - w/2, accs,     w, label="Test Accuracy",    color=colors,  edgecolor="white", alpha=0.9)
b2 = ax.bar(x + w/2, cv_means, w, label="CV Accuracy (5-fold)", color=colors, edgecolor="white", alpha=0.5)
ax.bar_label(b1, fmt="%.1f%%", padding=3, fontsize=9)
ax.bar_label(b2, fmt="%.1f%%", padding=3, fontsize=9)
ax.set_xticks(x); ax.set_xticklabels(names, rotation=15, ha="right")
ax.set_ylim(35, 72); ax.set_ylabel("Accuracy (%)")
ax.set_title("5 Algorithm Accuracy Comparison — Test vs Cross-Validation",
             fontsize=13, fontweight="bold")
ax.legend(); plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/01_accuracy_comparison.png", dpi=150)
plt.close()
print("      01_accuracy_comparison.png")

# ── Plot 2: Confusion matrices (all 5, one grid) ─────────────
fig, axes = plt.subplots(2, 3, figsize=(15, 9))
axes = axes.flatten()

for idx, (name, r) in enumerate(results.items()):
    cm = confusion_matrix(y_test, r["preds"])
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=le.classes_, yticklabels=le.classes_,
                linewidths=0.5, ax=axes[idx], cbar=False)
    axes[idx].set_title(f"{name}\n({r['accuracy']}% acc)", fontsize=11, fontweight="bold")
    axes[idx].set_xlabel("Predicted"); axes[idx].set_ylabel("Actual")

axes[5].axis("off")   # hide the 6th empty cell
fig.suptitle("Confusion Matrices — All 5 Models", fontsize=14, fontweight="bold", y=1.01)
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/02_all_confusion_matrices.png", dpi=150, bbox_inches="tight")
plt.close()
print("      02_all_confusion_matrices.png")

# ── Plot 3: F1 scores comparison ─────────────────────────────
f1s = [r["f1"] for r in results.values()]
fig, ax = plt.subplots(figsize=(10, 5))
bars = ax.bar(names, f1s, color=colors, edgecolor="white", width=0.55)
ax.bar_label(bars, fmt="%.4f", padding=3, fontsize=10)
ax.set_ylim(0.3, 0.7); ax.set_ylabel("Weighted F1 Score")
ax.set_title("F1 Score Comparison Across 5 Models", fontsize=13, fontweight="bold")
plt.xticks(rotation=15, ha="right"); plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/03_f1_comparison.png", dpi=150)
plt.close()
print("      03_f1_comparison.png")

# ── Plot 4: Feature importance (XGBoost + Decision Tree) ─────
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# XGBoost importance
xgb_r  = results["XGBoost"]
xgb_imp = pd.Series(xgb_r["model"].feature_importances_, index=FEATURE_COLS).sort_values()
axes[0].barh(xgb_imp.index, xgb_imp.values, color="#38bdf8", edgecolor="white")
axes[0].set_title("XGBoost — Feature Importance", fontsize=12, fontweight="bold")
axes[0].set_xlabel("Importance Score")

# Decision Tree importance
dt_r   = results["Decision Tree"]
dt_imp = pd.Series(dt_r["model"].feature_importances_, index=FEATURE_COLS).sort_values()
axes[1].barh(dt_imp.index, dt_imp.values, color="#22c55e", edgecolor="white")
axes[1].set_title("Decision Tree — Feature Importance", fontsize=12, fontweight="bold")
axes[1].set_xlabel("Importance Score")

plt.suptitle("Feature Importance: XGBoost vs Decision Tree", fontsize=13, fontweight="bold")
plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/04_feature_importance.png", dpi=150)
plt.close()
print("      04_feature_importance.png")

# ── Plot 5: CV score distribution (box plot) ─────────────────
cv_all = {}
for name, cfg in models_config.items():
    r   = results[name]
    Xal = X_all_scaled if cfg["scaled"] else X
    sc  = cross_val_score(cfg["model"], Xal, y_enc, cv=5, scoring="accuracy") * 100
    cv_all[name] = sc

cv_df = pd.DataFrame(cv_all)
fig, ax = plt.subplots(figsize=(10, 5))
bp = ax.boxplot(cv_df.values, patch_artist=True, notch=False,
                medianprops=dict(color="white", linewidth=2))
for patch, color in zip(bp["boxes"], colors):
    patch.set_facecolor(color); patch.set_alpha(0.75)
ax.set_xticklabels(names, rotation=15, ha="right")
ax.set_ylabel("CV Accuracy (%)")
ax.set_title("Cross-Validation Score Distribution (5 folds)", fontsize=13, fontweight="bold")
ax.set_ylim(35, 72); plt.tight_layout()
plt.savefig(f"{PLOTS_DIR}/05_cv_boxplot.png", dpi=150)
plt.close()
print("      05_cv_boxplot.png")

# ─── STEP 8: Final summary ────────────────────────────────────
print("\n[8/8] Final Summary")
print("=" * 58)
print(f"  {'Algorithm':<25} {'Accuracy':>9} {'F1':>8} {'CV Mean':>9}")
print("  " + "─" * 54)
for name, r in sorted(results.items(), key=lambda x: x[1]["accuracy"], reverse=True):
    best_flag = " ← BEST" if r["accuracy"] == max(r2["accuracy"] for r2 in results.values()) else ""
    print(f"  {name:<25} {r['accuracy']:>8.1f}% {r['f1']:>8.4f} {r['cv_mean']:>8.1f}%{best_flag}")
print("=" * 58)
print("\n✓  Stage 4 complete — 5 models trained and saved!")
print("   Run stage5_evaluation/api.py next.")
