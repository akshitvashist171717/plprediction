"""
=============================================================
 STAGE 5 — REST API Backend  (5 Models)
 Language : Python (Flask)
 Run      : python api.py
 Endpoint : http://localhost:5000
=============================================================

Install:  pip install flask flask-cors
Run    :  python api.py
"""

from flask      import Flask, request, jsonify
from flask_cors import CORS
import pickle, json
import numpy  as np
import pandas as pd
import os

app = Flask(__name__)
CORS(app)

MODELS_DIR = "../stage4_models/models"

# ─── Load all 5 models ────────────────────────────────────────
print("Loading models from disk...")

MODEL_FILES = {
    "lr"  : "Logistic Regression",
    "knn" : "K-Nearest Neighbors",
    "dt"  : "Decision Tree",
    "rf"  : "Random Forest",
    "xgb" : "XGBoost",
}

loaded_models = {}
for short, name in MODEL_FILES.items():
    path = f"{MODELS_DIR}/{short}.pkl"
    if os.path.exists(path):
        with open(path, "rb") as f:
            loaded_models[short] = pickle.load(f)
        print(f"  ✓ {name}")
    else:
        print(f"  ✗ {name} — file not found: {path}")

with open(f"{MODELS_DIR}/label_encoder.pkl", "rb") as f:
    label_enc = pickle.load(f)
with open(f"{MODELS_DIR}/scaler.pkl",        "rb") as f:
    scaler    = pickle.load(f)
with open(f"{MODELS_DIR}/model_results.json","r") as f:
    model_info = json.load(f)

FEATURE_COLS = model_info["feature_cols"]

# Models that need scaled input
SCALED_MODELS = {"lr", "knn"}

print(f"\n✓ All models loaded. Ready at http://localhost:5000\n")

# ─── ROUTES ───────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status"       : "ok",
        "models_loaded": list(loaded_models.keys()),
        "total_models" : len(loaded_models),
    })

@app.route("/models", methods=["GET"])
def get_models():
    """Returns info about all 5 available models."""
    info = {}
    for short, name in MODEL_FILES.items():
        if name in model_info:
            info[short] = {
                "name"     : name,
                "accuracy" : model_info[name]["accuracy"],
                "f1"       : model_info[name]["f1"],
                "cv_mean"  : model_info[name]["cv_mean"],
                "cv_std"   : model_info[name]["cv_std"],
                "color"    : model_info[name]["color"],
            }
    return jsonify(info)

@app.route("/teams", methods=["GET"])
def teams():
    try:
        df = pd.read_csv("../stage2_eda/clean_data.csv")
        all_teams = sorted(set(df["HomeTeam"].dropna()) | set(df["AwayTeam"].dropna()))
        return jsonify({"teams": all_teams})
    except:
        fallback = [
            "Arsenal","Aston Villa","Brentford","Brighton","Burnley",
            "Chelsea","Crystal Palace","Everton","Fulham","Leeds United",
            "Leicester City","Liverpool","Manchester City","Manchester United",
            "Newcastle United","Norwich City","Sheffield United","Southampton",
            "Tottenham Hotspur","Watford","West Ham United","Wolves"
        ]
        return jsonify({"teams": fallback})

@app.route("/predict", methods=["POST"])
def predict():
    """
    POST body (JSON):
    {
        "model": "xgb",        one of: lr, knn, dt, rf, xgb
        "home_team": "Arsenal",
        "away_team": "Chelsea",
        "home_form_gf": 8,
        ... (all feature_cols)
    }
    """
    try:
        data      = request.get_json()
        model_key = data.get("model", "xgb").lower()

        if model_key not in loaded_models:
            return jsonify({"error": f"Model '{model_key}' not found. Use: lr, knn, dt, rf, xgb"}), 400

        model = loaded_models[model_key]

        # Build feature vector
        row = []
        for col in FEATURE_COLS:
            val = data.get(col)
            if val is None:
                return jsonify({"error": f"Missing feature: '{col}'"}), 400
            row.append(float(val))

        X = np.array([row])

        # Scale if needed
        if model_key in SCALED_MODELS:
            X = scaler.transform(X)

        # Predict
        pred_class  = model.predict(X)[0]
        proba       = model.predict_proba(X)[0]
        pred_label  = label_enc.inverse_transform([pred_class])[0]
        classes     = label_enc.classes_
        prob_dict   = {cls: round(float(p)*100, 1) for cls, p in zip(classes, proba)}

        model_name  = MODEL_FILES[model_key]
        result_text = {
            "H": f"Home Win — {data.get('home_team','Home')}",
            "D": "Draw",
            "A": f"Away Win — {data.get('away_team','Away')}",
        }.get(pred_label, "Unknown")

        return jsonify({
            "prediction"    : pred_label,
            "result_text"   : result_text,
            "probabilities" : prob_dict,
            "model_used"    : model_name,
            "accuracy"      : model_info.get(model_name, {}).get("accuracy", "N/A"),
            "f1"            : model_info.get(model_name, {}).get("f1", "N/A"),
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/predict_all", methods=["POST"])
def predict_all():
    """
    Run all 5 models at once and return all predictions.
    Same body as /predict but no 'model' key needed.
    """
    try:
        data = request.get_json()

        row = []
        for col in FEATURE_COLS:
            val = data.get(col)
            if val is None:
                return jsonify({"error": f"Missing feature: '{col}'"}), 400
            row.append(float(val))

        X_raw    = np.array([row])
        X_scaled = scaler.transform(X_raw)

        all_results = {}
        for short, name in MODEL_FILES.items():
            if short not in loaded_models:
                continue
            model = loaded_models[short]
            X     = X_scaled if short in SCALED_MODELS else X_raw
            pred  = model.predict(X)[0]
            proba = model.predict_proba(X)[0]
            label = label_enc.inverse_transform([pred])[0]
            probs = {cls: round(float(p)*100,1)
                     for cls, p in zip(label_enc.classes_, proba)}
            all_results[short] = {
                "name"          : name,
                "prediction"    : label,
                "probabilities" : probs,
                "accuracy"      : model_info.get(name,{}).get("accuracy","N/A"),
            }

        return jsonify({"models": all_results})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    print("─" * 50)
    print("  PL Predictor API  — 5 Model Version")
    print("  http://localhost:5000")
    print("  Endpoints:")
    print("    GET  /health        check server")
    print("    GET  /teams         list all teams")
    print("    GET  /models        all 5 model stats")
    print("    POST /predict       single model prediction")
    print("    POST /predict_all   all 5 at once")
    print("─" * 50)
    app.run(debug=True, port=5000)
