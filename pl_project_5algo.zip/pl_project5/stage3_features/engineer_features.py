"""
=============================================================
 STAGE 3 — Feature Engineering
 Language : Python
 Run      : python engineer_features.py
 Input    : ../stage2_eda/clean_data.csv
 Output   : features.csv
=============================================================
"""

import pandas as pd
import numpy as np

INPUT_FILE  = "../stage2_eda/clean_data.csv"
OUTPUT_FILE = "features.csv"
FORM_WINDOW = 5

print("[1/5] Loading clean data...")
df = pd.read_csv(INPUT_FILE)
df["Date"] = pd.to_datetime(df["Date"])
df = df.sort_values("Date").reset_index(drop=True)
print(f"      Rows: {len(df)}")

def get_team_form(df, team, before_date, n=5):
    past = df[
        (df["Date"] < before_date) &
        ((df["HomeTeam"] == team) | (df["AwayTeam"] == team))
    ].tail(n)
    if len(past) == 0:
        return 0, 0, 0, 0
    gf = ga = wins = 0
    for _, row in past.iterrows():
        if row["HomeTeam"] == team:
            gf += row["FTHG"]; ga += row["FTAG"]
            if row["FTR"] == "H": wins += 1
        else:
            gf += row["FTAG"]; ga += row["FTHG"]
            if row["FTR"] == "A": wins += 1
    return gf, ga, wins, wins * 3

def get_h2h(df, home_team, away_team, before_date):
    past = df[
        (df["Date"] < before_date) &
        (((df["HomeTeam"]==home_team)&(df["AwayTeam"]==away_team)) |
         ((df["HomeTeam"]==away_team)&(df["AwayTeam"]==home_team)))
    ]
    if len(past) == 0:
        return 0, 0, 0
    hw = draws = aw = 0
    for _, row in past.iterrows():
        if row["HomeTeam"] == home_team:
            if row["FTR"]=="H": hw+=1
            elif row["FTR"]=="D": draws+=1
            else: aw+=1
        else:
            if row["FTR"]=="A": hw+=1
            elif row["FTR"]=="D": draws+=1
            else: aw+=1
    return hw, draws, aw

print(f"[2/5] Engineering features (takes ~3-5 minutes)...")
records = []
total = len(df)

for i, row in df.iterrows():
    if i % 500 == 0:
        print(f"      Progress: {i}/{total}")
    home = row["HomeTeam"]; away = row["AwayTeam"]; date = row["Date"]
    hgf, hga, hwins, hpts = get_team_form(df, home, date, FORM_WINDOW)
    agf, aga, awins, apts = get_team_form(df, away, date, FORM_WINDOW)
    h2h_hw, h2h_d, h2h_aw = get_h2h(df, home, away, date)

    records.append({
        "Date": date, "HomeTeam": home, "AwayTeam": away,
        "FTHG": row["FTHG"], "FTAG": row["FTAG"], "FTR": row["FTR"],
        "home_form_gf": hgf, "home_form_ga": hga,
        "home_form_wins": hwins, "home_form_pts": hpts,
        "home_goal_diff": hgf - hga,
        "away_form_gf": agf, "away_form_ga": aga,
        "away_form_wins": awins, "away_form_pts": apts,
        "away_goal_diff": agf - aga,
        "h2h_home_wins": h2h_hw, "h2h_draws": h2h_d, "h2h_away_wins": h2h_aw,
    })

print("[3/5] Building dataframe...")
features_df = pd.DataFrame(records)
print(f"      Shape: {features_df.shape}")

print("[4/5] Null check:")
print(features_df.isnull().sum())

features_df.to_csv(OUTPUT_FILE, index=False)
print(f"[5/5] Saved → {OUTPUT_FILE}")
print("\n✓  Stage 3 complete. Run stage4_models/train_models.py next.")
