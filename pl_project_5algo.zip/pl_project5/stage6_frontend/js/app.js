/**
 * =============================================================
 *  STAGE 6 — Frontend JavaScript  (5 Model Version)
 *  Language : JavaScript
 *  File     : app.js
 * =============================================================
 */

"use strict";

const API_URL = "http://localhost:5000";

// Default form values for demo mode
const DEMO_FORM = {
  home_form_gf: 7,  home_form_ga: 5,  home_form_wins: 2,
  home_form_pts: 6, home_goal_diff: 2,
  away_form_gf: 5,  away_form_ga: 6,  away_form_wins: 1,
  away_form_pts: 3, away_goal_diff: -1,
  h2h_home_wins: 4, h2h_draws: 3,     h2h_away_wins: 3,
};

// Per-model accent colors (match CSS variables)
const MODEL_COLORS = {
  lr:  "#94a3b8",
  knn: "#fb923c",
  dt:  "#4ade80",
  rf:  "#818cf8",
  xgb: "#38bdf8",
};
const MODEL_NAMES = {
  lr:  "Logistic Regression",
  knn: "K-Nearest Neighbors",
  dt:  "Decision Tree",
  rf:  "Random Forest",
  xgb: "XGBoost",
};
const MODEL_ACCURACY = { lr: "~51%", knn: "~50%", dt: "~52%", rf: "~55%", xgb: "~58%" };

let activeModel = "xgb";
let predictAll  = false;
let apiOnline   = false;

// DOM refs
const homeSelect    = document.getElementById("home-team");
const awaySelect    = document.getElementById("away-team");
const predictBtn    = document.getElementById("predict-btn");
const resultPanel   = document.getElementById("result-panel");
const allPanel      = document.getElementById("all-results-panel");
const errorMsg      = document.getElementById("error-msg");
const spinner       = document.getElementById("spinner");
const dotEl         = document.getElementById("api-dot");
const statusEl      = document.getElementById("api-status-text");

// ── Init ──────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  await checkApi();
  await loadTeams();
  await loadModelStats();
});

async function checkApi() {
  try {
    const res = await fetch(`${API_URL}/health`, { signal: AbortSignal.timeout(2000) });
    if (res.ok) {
      apiOnline = true;
      dotEl.classList.add("online");
      statusEl.textContent = "API connected — live predictions";
    }
  } catch {
    dotEl.classList.add("offline");
    statusEl.textContent = "API offline — demo mode active";
  }
}

async function loadTeams() {
  const FALLBACK = [
    "Arsenal","Aston Villa","Brentford","Brighton","Burnley",
    "Chelsea","Crystal Palace","Everton","Fulham","Leeds United",
    "Leicester City","Liverpool","Manchester City","Manchester United",
    "Newcastle United","Norwich City","Sheffield United","Southampton",
    "Tottenham Hotspur","Watford","West Ham United","Wolves"
  ];
  let teams = FALLBACK;
  try {
    if (apiOnline) {
      const res  = await fetch(`${API_URL}/teams`);
      const data = await res.json();
      teams = data.teams;
    }
  } catch {}

  [homeSelect, awaySelect].forEach((sel, i) => {
    sel.innerHTML = `<option value="">Select team...</option>`;
    teams.forEach(t => {
      const o = document.createElement("option");
      o.value = o.textContent = t;
      sel.appendChild(o);
    });
    sel.value = i === 0 ? "Arsenal" : "Chelsea";
  });
}

async function loadModelStats() {
  if (!apiOnline) return;
  try {
    const res  = await fetch(`${API_URL}/models`);
    const data = await res.json();
    for (const [short, info] of Object.entries(data)) {
      const accEl = document.getElementById(`acc-${short}`);
      const barEl = document.getElementById(`bar-${short}`);
      const f1El  = document.getElementById(`f1-${short}`);
      if (accEl) accEl.textContent = info.accuracy + "%";
      if (barEl) barEl.style.width = info.accuracy + "%";
      if (f1El)  f1El.textContent  = info.f1;
    }
  } catch (e) {
    console.warn("Could not load model stats:", e);
  }
}

// ── Model selection ───────────────────────────────────────────
function selectModel(btn) {
  document.querySelectorAll(".model-btn, .all-btn").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  activeModel = btn.dataset.model || "xgb";
  predictAll  = btn.dataset.all === "true";
}

// ── Main predict ──────────────────────────────────────────────
async function predict() {
  const home = homeSelect.value;
  const away = awaySelect.value;
  if (!home || !away)       { showError("Please select both teams."); return; }
  if (home === away)        { showError("Home and away teams must be different."); return; }
  hideError();

  predictBtn.disabled = true;
  spinner.classList.add("show");

  try {
    if (predictAll) {
      await runAllModels(home, away);
    } else {
      await runSingleModel(home, away, activeModel);
    }
  } catch (err) {
    showError(`Error: ${err.message}`);
  } finally {
    predictBtn.disabled = false;
    spinner.classList.remove("show");
  }
}

// ── Single model prediction ────────────────────────────────────
async function runSingleModel(home, away, modelKey) {
  let result;
  if (apiOnline) {
    const res = await fetch(`${API_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: modelKey, home_team: home, away_team: away, ...DEMO_FORM }),
    });
    result = await res.json();
    if (result.error) throw new Error(result.error);
  } else {
    result = simulateSingle(home, away, modelKey);
  }

  // Hide all-models panel, show single panel
  allPanel.classList.remove("show");

  // Populate
  const color = MODEL_COLORS[modelKey];
  document.getElementById("result-model-tag").textContent  = MODEL_NAMES[modelKey];
  document.getElementById("result-model-tag").style.background = `${color}18`;
  document.getElementById("result-model-tag").style.color      = color;
  document.getElementById("result-model-tag").style.borderColor = `${color}40`;
  document.getElementById("result-match-title").textContent = `${home} vs ${away}`;

  const p = result.probabilities;
  setBar("home", `${home} win`, p["H"]||0, "var(--blue)");
  setBar("draw", "Draw",        p["D"]||0, "var(--yellow)");
  setBar("away", `${away} win`, p["A"]||0, "var(--purple)");

  const pred = result.prediction;
  const maxP = Math.max(p["H"]||0, p["D"]||0, p["A"]||0);
  const vBox = document.getElementById("verdict-box");
  vBox.className = "verdict " + { H:"home", D:"draw", A:"away" }[pred];
  document.getElementById("verdict-icon").textContent = { H:"🏠", D:"🤝", A:"✈️" }[pred];
  document.getElementById("verdict-text").textContent = {
    H: `Home Win — ${home}`, D: "Draw", A: `Away Win — ${away}`
  }[pred];

  document.getElementById("stat-accuracy").textContent  = result.accuracy ? result.accuracy + "%" : MODEL_ACCURACY[modelKey];
  document.getElementById("stat-confidence").textContent = maxP.toFixed(1) + "%";
  document.getElementById("stat-f1").textContent         = result.f1 || "—";

  showPanel(resultPanel);
}

// ── All-5 models prediction ────────────────────────────────────
async function runAllModels(home, away) {
  let allData;
  if (apiOnline) {
    const res = await fetch(`${API_URL}/predict_all`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ home_team: home, away_team: away, ...DEMO_FORM }),
    });
    const json = await res.json();
    if (json.error) throw new Error(json.error);
    allData = json.models;
  } else {
    // Simulate all 5
    allData = {};
    for (const short of ["lr","knn","dt","rf","xgb"]) {
      const r = simulateSingle(home, away, short);
      allData[short] = { name: MODEL_NAMES[short], prediction: r.prediction,
                         probabilities: r.probabilities, accuracy: MODEL_ACCURACY[short] };
    }
  }

  resultPanel.classList.remove("show");
  document.getElementById("all-match-title").textContent = `${home} vs ${away}`;

  // Count votes
  const votes = { H:0, D:0, A:0 };
  for (const r of Object.values(allData)) votes[r.prediction]++;
  const consensusPred = Object.entries(votes).sort((a,b)=>b[1]-a[1])[0][0];
  const consensusText = { H:`Home Win — ${home}`, D:"Draw", A:`Away Win — ${away}` }[consensusPred];
  document.getElementById("consensus-text").textContent = `${consensusText}  (${votes[consensusPred]}/5 models agree)`;

  // Build cards
  const grid = document.getElementById("all-results-grid");
  grid.innerHTML = "";
  const sortedOrder = ["lr","knn","dt","rf","xgb"];
  for (const short of sortedOrder) {
    const r     = allData[short];
    const color = MODEL_COLORS[short];
    const pred  = r.prediction;
    const probs = r.probabilities;
    const conf  = Math.max(probs["H"]||0, probs["D"]||0, probs["A"]||0);
    const isWin = conf === Math.max(...Object.values(allData).map(x => Math.max(x.probabilities["H"]||0, x.probabilities["D"]||0, x.probabilities["A"]||0)));

    const card = document.createElement("div");
    card.className = "model-result-card" + (pred === consensusPred ? " winner" : "");
    card.style.borderTopColor = color;
    card.innerHTML = `
      <div class="mr-name" style="color:${color}">${r.name}</div>
      <div class="mr-pred pred-${pred}">${{ H:"HOME WIN", D:"DRAW", A:"AWAY WIN" }[pred]}</div>
      <div class="mr-conf">${conf.toFixed(1)}% confidence</div>
      <div class="mr-acc">Accuracy: ${r.accuracy}</div>
      <div class="prob-bars" style="margin-top:10px">
        <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px">
          <span style="color:var(--blue)">H ${(probs["H"]||0).toFixed(0)}%</span>
          <span style="color:var(--yellow)">D ${(probs["D"]||0).toFixed(0)}%</span>
          <span style="color:var(--purple)">A ${(probs["A"]||0).toFixed(0)}%</span>
        </div>
        <div style="height:5px;background:var(--surface2);border-radius:3px;display:flex;overflow:hidden">
          <div style="width:${probs["H"]||0}%;background:var(--blue)"></div>
          <div style="width:${probs["D"]||0}%;background:var(--yellow)"></div>
          <div style="width:${probs["A"]||0}%;background:var(--purple)"></div>
        </div>
      </div>
      ${pred === consensusPred ? '<div class="winner-badge">Matches consensus</div>' : ''}
    `;
    grid.appendChild(card);
  }

  showPanel(allPanel);
}

// ── Helper: set one probability bar ──────────────────────────
function setBar(id, label, pct, color) {
  document.getElementById(`prob-name-${id}`).textContent = label;
  document.getElementById(`prob-name-${id}`).style.color = color;
  document.getElementById(`prob-pct-${id}`).textContent  = pct.toFixed(1) + "%";
  document.getElementById(`prob-pct-${id}`).style.color  = color;
  const bar = document.getElementById(`bar-${id}`);
  bar.style.width = "0%";
  setTimeout(() => { bar.style.width = pct + "%"; }, 60);
}

// ── Show a panel with animation ───────────────────────────────
function showPanel(el) {
  el.classList.remove("show");
  void el.offsetWidth;
  el.style.display = "block";
  requestAnimationFrame(() => el.classList.add("show"));
  el.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

// ── Demo simulation ────────────────────────────────────────────
function simulateSingle(home, away, model) {
  const seed = ([...home].reduce((a,c)=>a+c.charCodeAt(0),0)*3 +
                [...away].reduce((a,c)=>a+c.charCodeAt(0),0)*7 +
                { lr:5, knn:9, dt:13, rf:17, xgb:23 }[model]) % 100;
  let h = 36 + (seed % 22), d = 22 + (seed % 12);
  let a = 100 - h - d;
  if (a < 8) { a = 12; h = 100 - d - a; }
  const tot = h + d + a;
  h = Math.round(h/tot*100); d = Math.round(d/tot*100); a = 100 - h - d;
  const pred = h>=d&&h>=a?"H":d>=h&&d>=a?"D":"A";
  return {
    prediction: pred, accuracy: MODEL_ACCURACY[model], f1: "—",
    probabilities: { H: h, D: d, A: a },
    model_used: MODEL_NAMES[model],
  };
}

function showError(msg) { errorMsg.textContent = "⚠ " + msg; errorMsg.classList.add("show"); }
function hideError()    { errorMsg.classList.remove("show"); }

window.selectModel = selectModel;
window.predict     = predict;
